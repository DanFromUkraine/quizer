(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_initializers_InitMainDbAtoms_tsx_9d422d41._.js",
  "static/chunks/src_components_initializers_InitMainDbAtoms_tsx_4e6ca0fb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
}]);