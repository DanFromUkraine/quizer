(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "RESET": ()=>RESET,
    "atomFamily": ()=>atomFamily,
    "atomWithDefault": ()=>atomWithDefault,
    "atomWithLazy": ()=>atomWithLazy,
    "atomWithObservable": ()=>atomWithObservable,
    "atomWithReducer": ()=>atomWithReducer,
    "atomWithRefresh": ()=>atomWithRefresh,
    "atomWithReset": ()=>atomWithReset,
    "atomWithStorage": ()=>atomWithStorage,
    "createJSONStorage": ()=>createJSONStorage,
    "freezeAtom": ()=>freezeAtom,
    "freezeAtomCreator": ()=>freezeAtomCreator,
    "loadable": ()=>loadable,
    "selectAtom": ()=>selectAtom,
    "splitAtom": ()=>splitAtom,
    "unstable_withStorageValidator": ()=>withStorageValidator,
    "unwrap": ()=>unwrap
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs")}`;
    }
};
;
const RESET = Symbol((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" ? "RESET" : "");
function atomWithReset(initialValue) {
    const anAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(initialValue, (get, set, update)=>{
        const nextValue = typeof update === "function" ? update(get(anAtom)) : update;
        set(anAtom, nextValue === RESET ? initialValue : nextValue);
    });
    return anAtom;
}
function atomWithReducer(initialValue, reducer) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(initialValue, function(get, set, action) {
        set(this, reducer(get(this), action));
    });
}
function atomFamily(initializeAtom, areEqual) {
    let shouldRemove = null;
    const atoms = /* @__PURE__ */ new Map();
    const listeners = /* @__PURE__ */ new Set();
    const createAtom = (param)=>{
        let item;
        if (areEqual === void 0) {
            item = atoms.get(param);
        } else {
            for (const [key, value] of atoms){
                if (areEqual(key, param)) {
                    item = value;
                    break;
                }
            }
        }
        if (item !== void 0) {
            if (shouldRemove == null ? void 0 : shouldRemove(item[1], param)) {
                createAtom.remove(param);
            } else {
                return item[0];
            }
        }
        const newAtom = initializeAtom(param);
        atoms.set(param, [
            newAtom,
            Date.now()
        ]);
        notifyListeners("CREATE", param, newAtom);
        return newAtom;
    };
    const notifyListeners = (type, param, atom)=>{
        for (const listener of listeners){
            listener({
                type,
                param,
                atom
            });
        }
    };
    createAtom.unstable_listen = (callback)=>{
        listeners.add(callback);
        return ()=>{
            listeners.delete(callback);
        };
    };
    createAtom.getParams = ()=>atoms.keys();
    createAtom.remove = (param)=>{
        if (areEqual === void 0) {
            if (!atoms.has(param)) return;
            const [atom] = atoms.get(param);
            atoms.delete(param);
            notifyListeners("REMOVE", param, atom);
        } else {
            for (const [key, [atom]] of atoms){
                if (areEqual(key, param)) {
                    atoms.delete(key);
                    notifyListeners("REMOVE", key, atom);
                    break;
                }
            }
        }
    };
    createAtom.setShouldRemove = (fn)=>{
        shouldRemove = fn;
        if (!shouldRemove) return;
        for (const [key, [atom, createdAt]] of atoms){
            if (shouldRemove(createdAt, key)) {
                atoms.delete(key);
                notifyListeners("REMOVE", key, atom);
            }
        }
    };
    return createAtom;
}
const getCached$2 = (c, m, k)=>(m.has(k) ? m : m.set(k, c())).get(k);
const cache1$3 = /* @__PURE__ */ new WeakMap();
const memo3 = (create, dep1, dep2, dep3)=>{
    const cache2 = getCached$2(()=>/* @__PURE__ */ new WeakMap(), cache1$3, dep1);
    const cache3 = getCached$2(()=>/* @__PURE__ */ new WeakMap(), cache2, dep2);
    return getCached$2(create, cache3, dep3);
};
function selectAtom(anAtom, selector) {
    let equalityFn = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Object.is;
    return memo3(()=>{
        const EMPTY = Symbol();
        const selectValue = (param)=>{
            let [value, prevSlice] = param;
            if (prevSlice === EMPTY) {
                return selector(value);
            }
            const slice = selector(value, prevSlice);
            return equalityFn(prevSlice, slice) ? prevSlice : slice;
        };
        const derivedAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
            const prev = get(derivedAtom);
            const value = get(anAtom);
            return selectValue([
                value,
                prev
            ]);
        });
        derivedAtom.init = EMPTY;
        return derivedAtom;
    }, anAtom, selector, equalityFn);
}
const frozenAtoms = /* @__PURE__ */ new WeakSet();
const deepFreeze = (value)=>{
    if (typeof value !== "object" || value === null) {
        return value;
    }
    Object.freeze(value);
    const propNames = Object.getOwnPropertyNames(value);
    for (const name of propNames){
        deepFreeze(value[name]);
    }
    return value;
};
function freezeAtom(anAtom) {
    if (frozenAtoms.has(anAtom)) {
        return anAtom;
    }
    frozenAtoms.add(anAtom);
    const origRead = anAtom.read;
    anAtom.read = function(get, options) {
        return deepFreeze(origRead.call(this, get, options));
    };
    if ("write" in anAtom) {
        const origWrite = anAtom.write;
        anAtom.write = function(get, set) {
            for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
                args[_key - 2] = arguments[_key];
            }
            return origWrite.call(this, get, function() {
                for(var _len = arguments.length, setArgs = new Array(_len), _key = 0; _key < _len; _key++){
                    setArgs[_key] = arguments[_key];
                }
                if (setArgs[0] === anAtom) {
                    setArgs[1] = deepFreeze(setArgs[1]);
                }
                return set(...setArgs);
            }, ...args);
        };
    }
    return anAtom;
}
function freezeAtomCreator(createAtom) {
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        console.warn("[DEPRECATED] freezeAtomCreator is deprecated, define it on users end");
    }
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        return freezeAtom(createAtom(...args));
    };
}
const getCached$1 = (c, m, k)=>(m.has(k) ? m : m.set(k, c())).get(k);
const cache1$2 = /* @__PURE__ */ new WeakMap();
const memo2$1 = (create, dep1, dep2)=>{
    const cache2 = getCached$1(()=>/* @__PURE__ */ new WeakMap(), cache1$2, dep1);
    return getCached$1(create, cache2, dep2);
};
const cacheKeyForEmptyKeyExtractor = {};
const isWritable = (atom2)=>!!atom2.write;
const isFunction = (x)=>typeof x === "function";
function splitAtom(arrAtom, keyExtractor) {
    return memo2$1(()=>{
        const mappingCache = /* @__PURE__ */ new WeakMap();
        const getMapping = (arr, prev)=>{
            let mapping = mappingCache.get(arr);
            if (mapping) {
                return mapping;
            }
            const prevMapping = prev && mappingCache.get(prev);
            const atomList = [];
            const keyList = [];
            arr.forEach((item, index)=>{
                const key = keyExtractor ? keyExtractor(item) : index;
                keyList[index] = key;
                const cachedAtom = prevMapping && prevMapping.atomList[prevMapping.keyList.indexOf(key)];
                if (cachedAtom) {
                    atomList[index] = cachedAtom;
                    return;
                }
                const read = (get)=>{
                    const prev2 = get(mappingAtom);
                    const currArr = get(arrAtom);
                    const mapping2 = getMapping(currArr, prev2 == null ? void 0 : prev2.arr);
                    const index2 = mapping2.keyList.indexOf(key);
                    if (index2 < 0 || index2 >= currArr.length) {
                        const prevItem = arr[getMapping(arr).keyList.indexOf(key)];
                        if (prevItem) {
                            return prevItem;
                        }
                        throw new Error("splitAtom: index out of bounds for read");
                    }
                    return currArr[index2];
                };
                const write = (get, set, update)=>{
                    const prev2 = get(mappingAtom);
                    const arr2 = get(arrAtom);
                    const mapping2 = getMapping(arr2, prev2 == null ? void 0 : prev2.arr);
                    const index2 = mapping2.keyList.indexOf(key);
                    if (index2 < 0 || index2 >= arr2.length) {
                        throw new Error("splitAtom: index out of bounds for write");
                    }
                    const nextItem = isFunction(update) ? update(arr2[index2]) : update;
                    if (!Object.is(arr2[index2], nextItem)) {
                        set(arrAtom, [
                            ...arr2.slice(0, index2),
                            nextItem,
                            ...arr2.slice(index2 + 1)
                        ]);
                    }
                };
                atomList[index] = isWritable(arrAtom) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(read, write) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(read);
            });
            if (prevMapping && prevMapping.keyList.length === keyList.length && prevMapping.keyList.every((x, i)=>x === keyList[i])) {
                mapping = prevMapping;
            } else {
                mapping = {
                    arr,
                    atomList,
                    keyList
                };
            }
            mappingCache.set(arr, mapping);
            return mapping;
        };
        const mappingAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
            const prev = get(mappingAtom);
            const arr = get(arrAtom);
            const mapping = getMapping(arr, prev == null ? void 0 : prev.arr);
            return mapping;
        });
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            mappingAtom.debugPrivate = true;
        }
        mappingAtom.init = void 0;
        const splittedAtom = isWritable(arrAtom) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(mappingAtom).atomList, (get, set, action)=>{
            switch(action.type){
                case "remove":
                    {
                        const index = get(splittedAtom).indexOf(action.atom);
                        if (index >= 0) {
                            const arr = get(arrAtom);
                            set(arrAtom, [
                                ...arr.slice(0, index),
                                ...arr.slice(index + 1)
                            ]);
                        }
                        break;
                    }
                case "insert":
                    {
                        const index = action.before ? get(splittedAtom).indexOf(action.before) : get(splittedAtom).length;
                        if (index >= 0) {
                            const arr = get(arrAtom);
                            set(arrAtom, [
                                ...arr.slice(0, index),
                                action.value,
                                ...arr.slice(index)
                            ]);
                        }
                        break;
                    }
                case "move":
                    {
                        const index1 = get(splittedAtom).indexOf(action.atom);
                        const index2 = action.before ? get(splittedAtom).indexOf(action.before) : get(splittedAtom).length;
                        if (index1 >= 0 && index2 >= 0) {
                            const arr = get(arrAtom);
                            if (index1 < index2) {
                                set(arrAtom, [
                                    ...arr.slice(0, index1),
                                    ...arr.slice(index1 + 1, index2),
                                    arr[index1],
                                    ...arr.slice(index2)
                                ]);
                            } else {
                                set(arrAtom, [
                                    ...arr.slice(0, index2),
                                    arr[index1],
                                    ...arr.slice(index2, index1),
                                    ...arr.slice(index1 + 1)
                                ]);
                            }
                        }
                        break;
                    }
            }
        }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(mappingAtom).atomList);
        return splittedAtom;
    }, arrAtom, keyExtractor || cacheKeyForEmptyKeyExtractor);
}
function atomWithDefault(getDefault) {
    const EMPTY = Symbol();
    const overwrittenAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(EMPTY);
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        overwrittenAtom.debugPrivate = true;
    }
    const anAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get, options)=>{
        const overwritten = get(overwrittenAtom);
        if (overwritten !== EMPTY) {
            return overwritten;
        }
        return getDefault(get, options);
    }, (get, set, update)=>{
        const newValue = typeof update === "function" ? update(get(anAtom)) : update;
        set(overwrittenAtom, newValue === RESET ? EMPTY : newValue);
    });
    return anAtom;
}
const isPromiseLike$3 = (x)=>typeof (x == null ? void 0 : x.then) === "function";
function withStorageValidator(validator) {
    return (unknownStorage)=>{
        const storage = {
            ...unknownStorage,
            getItem: (key, initialValue)=>{
                const validate = (value2)=>{
                    if (!validator(value2)) {
                        return initialValue;
                    }
                    return value2;
                };
                const value = unknownStorage.getItem(key, initialValue);
                if (isPromiseLike$3(value)) {
                    return value.then(validate);
                }
                return validate(value);
            }
        };
        return storage;
    };
}
function createJSONStorage() {
    let getStringStorage = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ()=>{
        try {
            return window.localStorage;
        } catch (e) {
            if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
                if (typeof window !== "undefined") {
                    console.warn(e);
                }
            }
            return void 0;
        }
    }, options = arguments.length > 1 ? arguments[1] : void 0;
    var _a;
    let lastStr;
    let lastValue;
    const storage = {
        getItem: (key, initialValue)=>{
            var _a2, _b;
            const parse = (str2)=>{
                str2 = str2 || "";
                if (lastStr !== str2) {
                    try {
                        lastValue = JSON.parse(str2, options == null ? void 0 : options.reviver);
                    } catch (e) {
                        return initialValue;
                    }
                    lastStr = str2;
                }
                return lastValue;
            };
            const str = (_b = (_a2 = getStringStorage()) == null ? void 0 : _a2.getItem(key)) != null ? _b : null;
            if (isPromiseLike$3(str)) {
                return str.then(parse);
            }
            return parse(str);
        },
        setItem: (key, newValue)=>{
            var _a2;
            return (_a2 = getStringStorage()) == null ? void 0 : _a2.setItem(key, JSON.stringify(newValue, options == null ? void 0 : options.replacer));
        },
        removeItem: (key)=>{
            var _a2;
            return (_a2 = getStringStorage()) == null ? void 0 : _a2.removeItem(key);
        }
    };
    const createHandleSubscribe = (subscriber2)=>(key, callback, initialValue)=>subscriber2(key, (v)=>{
                let newValue;
                try {
                    newValue = JSON.parse(v || "");
                } catch (e) {
                    newValue = initialValue;
                }
                callback(newValue);
            });
    let subscriber;
    try {
        subscriber = (_a = getStringStorage()) == null ? void 0 : _a.subscribe;
    } catch (e) {}
    if (!subscriber && typeof window !== "undefined" && typeof window.addEventListener === "function" && window.Storage) {
        subscriber = (key, callback)=>{
            if (!(getStringStorage() instanceof window.Storage)) {
                return ()=>{};
            }
            const storageEventCallback = (e)=>{
                if (e.storageArea === getStringStorage() && e.key === key) {
                    callback(e.newValue);
                }
            };
            window.addEventListener("storage", storageEventCallback);
            return ()=>{
                window.removeEventListener("storage", storageEventCallback);
            };
        };
    }
    if (subscriber) {
        storage.subscribe = createHandleSubscribe(subscriber);
    }
    return storage;
}
const defaultStorage = createJSONStorage();
function atomWithStorage(key, initialValue) {
    let storage = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : defaultStorage, options = arguments.length > 3 ? arguments[3] : void 0;
    const getOnInit = options == null ? void 0 : options.getOnInit;
    const baseAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(getOnInit ? storage.getItem(key, initialValue) : initialValue);
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        baseAtom.debugPrivate = true;
    }
    baseAtom.onMount = (setAtom)=>{
        setAtom(storage.getItem(key, initialValue));
        let unsub;
        if (storage.subscribe) {
            unsub = storage.subscribe(key, setAtom, initialValue);
        }
        return unsub;
    };
    const anAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(baseAtom), (get, set, update)=>{
        const nextValue = typeof update === "function" ? update(get(baseAtom)) : update;
        if (nextValue === RESET) {
            set(baseAtom, initialValue);
            return storage.removeItem(key);
        }
        if (isPromiseLike$3(nextValue)) {
            return nextValue.then((resolvedValue)=>{
                set(baseAtom, resolvedValue);
                return storage.setItem(key, resolvedValue);
            });
        }
        set(baseAtom, nextValue);
        return storage.setItem(key, nextValue);
    });
    return anAtom;
}
const isPromiseLike$2 = (x)=>typeof (x == null ? void 0 : x.then) === "function";
function atomWithObservable(getObservable, options) {
    const returnResultData = (result)=>{
        if ("e" in result) {
            throw result.e;
        }
        return result.d;
    };
    const observableResultAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        var _a;
        let observable = getObservable(get);
        const itself = (_a = observable[Symbol.observable]) == null ? void 0 : _a.call(observable);
        if (itself) {
            observable = itself;
        }
        let resolve;
        const makePending = ()=>new Promise((r)=>{
                resolve = r;
            });
        const initialResult = options && "initialValue" in options ? {
            d: typeof options.initialValue === "function" ? options.initialValue() : options.initialValue
        } : makePending();
        let setResult;
        let lastResult;
        const listener = (result)=>{
            lastResult = result;
            resolve == null ? void 0 : resolve(result);
            setResult == null ? void 0 : setResult(result);
        };
        let subscription;
        let timer;
        const isNotMounted = ()=>!setResult;
        const unsubscribe = ()=>{
            if (subscription) {
                subscription.unsubscribe();
                subscription = void 0;
            }
        };
        const start = ()=>{
            if (subscription) {
                clearTimeout(timer);
                subscription.unsubscribe();
            }
            subscription = observable.subscribe({
                next: (d)=>listener({
                        d
                    }),
                error: (e)=>listener({
                        e
                    }),
                complete: ()=>{}
            });
            if (isNotMounted() && (options == null ? void 0 : options.unstable_timeout)) {
                timer = setTimeout(unsubscribe, options.unstable_timeout);
            }
        };
        start();
        const resultAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(lastResult || initialResult);
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            resultAtom.debugPrivate = true;
        }
        resultAtom.onMount = (update)=>{
            setResult = update;
            if (lastResult) {
                update(lastResult);
            }
            if (subscription) {
                clearTimeout(timer);
            } else {
                start();
            }
            return ()=>{
                setResult = void 0;
                if (options == null ? void 0 : options.unstable_timeout) {
                    timer = setTimeout(unsubscribe, options.unstable_timeout);
                } else {
                    unsubscribe();
                }
            };
        };
        return [
            resultAtom,
            observable,
            makePending,
            start,
            isNotMounted
        ];
    });
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        observableResultAtom.debugPrivate = true;
    }
    const observableAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const [resultAtom] = get(observableResultAtom);
        const result = get(resultAtom);
        if (isPromiseLike$2(result)) {
            return result.then(returnResultData);
        }
        return returnResultData(result);
    }, (get, set, data)=>{
        const [resultAtom, observable, makePending, start, isNotMounted] = get(observableResultAtom);
        if ("next" in observable) {
            if (isNotMounted()) {
                set(resultAtom, makePending());
                start();
            }
            observable.next(data);
        } else {
            throw new Error("observable is not subject");
        }
    });
    return observableAtom;
}
const cache1$1 = /* @__PURE__ */ new WeakMap();
const memo1 = (create, dep1)=>(cache1$1.has(dep1) ? cache1$1 : cache1$1.set(dep1, create())).get(dep1);
const isPromiseLike$1 = (p)=>typeof (p == null ? void 0 : p.then) === "function";
const LOADING = {
    state: "loading"
};
function loadable(anAtom) {
    return memo1(()=>{
        const loadableCache = /* @__PURE__ */ new WeakMap();
        const refreshAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(0);
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            refreshAtom.debugPrivate = true;
        }
        const derivedAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get, param)=>{
            let { setSelf } = param;
            get(refreshAtom);
            let value;
            try {
                value = get(anAtom);
            } catch (error) {
                return {
                    state: "hasError",
                    error
                };
            }
            if (!isPromiseLike$1(value)) {
                return {
                    state: "hasData",
                    data: value
                };
            }
            const promise = value;
            const cached1 = loadableCache.get(promise);
            if (cached1) {
                return cached1;
            }
            promise.then((data)=>{
                loadableCache.set(promise, {
                    state: "hasData",
                    data
                });
                setSelf();
            }, (error)=>{
                loadableCache.set(promise, {
                    state: "hasError",
                    error
                });
                setSelf();
            });
            const cached2 = loadableCache.get(promise);
            if (cached2) {
                return cached2;
            }
            loadableCache.set(promise, LOADING);
            return LOADING;
        }, (_get, set)=>{
            set(refreshAtom, (c)=>c + 1);
        });
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            derivedAtom.debugPrivate = true;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(derivedAtom));
    }, anAtom);
}
const getCached = (c, m, k)=>(m.has(k) ? m : m.set(k, c())).get(k);
const cache1 = /* @__PURE__ */ new WeakMap();
const memo2 = (create, dep1, dep2)=>{
    const cache2 = getCached(()=>/* @__PURE__ */ new WeakMap(), cache1, dep1);
    return getCached(create, cache2, dep2);
};
const isPromiseLike = (p)=>typeof (p == null ? void 0 : p.then) === "function";
const defaultFallback = ()=>void 0;
function unwrap(anAtom) {
    let fallback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : defaultFallback;
    return memo2(()=>{
        const promiseErrorCache = /* @__PURE__ */ new WeakMap();
        const promiseResultCache = /* @__PURE__ */ new WeakMap();
        const refreshAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(0);
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            refreshAtom.debugPrivate = true;
        }
        const promiseAndValueAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get, param)=>{
            let { setSelf } = param;
            get(refreshAtom);
            const prev = get(promiseAndValueAtom);
            const promise = get(anAtom);
            if (!isPromiseLike(promise)) {
                return {
                    v: promise
                };
            }
            if (promise !== (prev == null ? void 0 : prev.p)) {
                promise.then((v)=>{
                    promiseResultCache.set(promise, v);
                    setSelf();
                }, (e)=>{
                    promiseErrorCache.set(promise, e);
                    setSelf();
                });
            }
            if (promiseErrorCache.has(promise)) {
                throw promiseErrorCache.get(promise);
            }
            if (promiseResultCache.has(promise)) {
                return {
                    p: promise,
                    v: promiseResultCache.get(promise)
                };
            }
            if (prev && "v" in prev) {
                return {
                    p: promise,
                    f: fallback(prev.v),
                    v: prev.v
                };
            }
            return {
                p: promise,
                f: fallback()
            };
        }, (_get, set)=>{
            set(refreshAtom, (c)=>c + 1);
        });
        promiseAndValueAtom.init = void 0;
        if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            promiseAndValueAtom.debugPrivate = true;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
            const state = get(promiseAndValueAtom);
            if ("f" in state) {
                return state.f;
            }
            return state.v;
        }, function(_get, set) {
            for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
                args[_key - 2] = arguments[_key];
            }
            return set(anAtom, ...args);
        });
    }, anAtom, fallback);
}
function atomWithRefresh(read, write) {
    const refreshAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(0);
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        refreshAtom.debugPrivate = true;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get, options)=>{
        get(refreshAtom);
        return read(get, options);
    }, function(get, set) {
        for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
            args[_key - 2] = arguments[_key];
        }
        if (args.length === 0) {
            set(refreshAtom, (c)=>c + 1);
        } else if (write) {
            return write(get, set, ...args);
        } else if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
            throw new Error("refresh must be called without arguments");
        }
    });
}
function atomWithLazy(makeInitial) {
    const a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(void 0);
    delete a.init;
    Object.defineProperty(a, "init", {
        get () {
            return makeInitial();
        }
    });
    return a;
}
;
}),
"[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "useAtomCallback": ()=>useAtomCallback,
    "useHydrateAtoms": ()=>useHydrateAtoms,
    "useReducerAtom": ()=>useReducerAtom,
    "useResetAtom": ()=>useResetAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs")}`;
    }
};
'use client';
;
;
;
;
function useResetAtom(anAtom, options) {
    const setAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(anAtom, options);
    const resetAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useResetAtom.useCallback[resetAtom]": ()=>setAtom(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RESET"])
    }["useResetAtom.useCallback[resetAtom]"], [
        setAtom
    ]);
    return resetAtom;
}
function useReducerAtom(anAtom, reducer, options) {
    if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") {
        console.warn("[DEPRECATED] useReducerAtom is deprecated and will be removed in the future. Please create your own version using the recipe. https://github.com/pmndrs/jotai/pull/2467");
    }
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])(anAtom, options);
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useReducerAtom.useCallback[dispatch]": (action)=>{
            setState({
                "useReducerAtom.useCallback[dispatch]": (prev)=>reducer(prev, action)
            }["useReducerAtom.useCallback[dispatch]"]);
        }
    }["useReducerAtom.useCallback[dispatch]"], [
        setState,
        reducer
    ]);
    return [
        state,
        dispatch
    ];
}
function useAtomCallback(callback, options) {
    const anAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useAtomCallback.useMemo[anAtom]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, {
                "useAtomCallback.useMemo[anAtom]": function(get, set) {
                    for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
                        args[_key - 2] = arguments[_key];
                    }
                    return callback(get, set, ...args);
                }
            }["useAtomCallback.useMemo[anAtom]"])
    }["useAtomCallback.useMemo[anAtom]"], [
        callback
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(anAtom, options);
}
const hydratedMap = /* @__PURE__ */ new WeakMap();
function useHydrateAtoms(values, options) {
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(options);
    const hydratedSet = getHydratedSet(store);
    for (const [atom, ...args] of values){
        if (!hydratedSet.has(atom) || (options == null ? void 0 : options.dangerouslyForceHydrate)) {
            hydratedSet.add(atom);
            store.set(atom, ...args);
        }
    }
}
const getHydratedSet = (store)=>{
    let hydratedSet = hydratedMap.get(store);
    if (!hydratedSet) {
        hydratedSet = /* @__PURE__ */ new WeakSet();
        hydratedMap.set(store, hydratedSet);
    }
    return hydratedSet;
};
;
}),
"[project]/node_modules/.pnpm/idb@8.0.3/node_modules/idb/build/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "deleteDB": ()=>deleteDB,
    "openDB": ()=>openDB,
    "unwrap": ()=>unwrap,
    "wrap": ()=>wrap
});
const instanceOfAny = (object, constructors)=>constructors.some((c)=>object instanceof c);
let idbProxyableTypes;
let cursorAdvanceMethods;
// This is a function to prevent it throwing up in node environments.
function getIdbProxyableTypes() {
    return idbProxyableTypes || (idbProxyableTypes = [
        IDBDatabase,
        IDBObjectStore,
        IDBIndex,
        IDBCursor,
        IDBTransaction
    ]);
}
// This is a function to prevent it throwing up in node environments.
function getCursorAdvanceMethods() {
    return cursorAdvanceMethods || (cursorAdvanceMethods = [
        IDBCursor.prototype.advance,
        IDBCursor.prototype.continue,
        IDBCursor.prototype.continuePrimaryKey
    ]);
}
const transactionDoneMap = new WeakMap();
const transformCache = new WeakMap();
const reverseTransformCache = new WeakMap();
function promisifyRequest(request) {
    const promise = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            request.removeEventListener('success', success);
            request.removeEventListener('error', error);
        };
        const success = ()=>{
            resolve(wrap(request.result));
            unlisten();
        };
        const error = ()=>{
            reject(request.error);
            unlisten();
        };
        request.addEventListener('success', success);
        request.addEventListener('error', error);
    });
    // This mapping exists in reverseTransformCache but doesn't exist in transformCache. This
    // is because we create many promises from a single IDBRequest.
    reverseTransformCache.set(promise, request);
    return promise;
}
function cacheDonePromiseForTransaction(tx) {
    // Early bail if we've already created a done promise for this transaction.
    if (transactionDoneMap.has(tx)) return;
    const done = new Promise((resolve, reject)=>{
        const unlisten = ()=>{
            tx.removeEventListener('complete', complete);
            tx.removeEventListener('error', error);
            tx.removeEventListener('abort', error);
        };
        const complete = ()=>{
            resolve();
            unlisten();
        };
        const error = ()=>{
            reject(tx.error || new DOMException('AbortError', 'AbortError'));
            unlisten();
        };
        tx.addEventListener('complete', complete);
        tx.addEventListener('error', error);
        tx.addEventListener('abort', error);
    });
    // Cache it for later retrieval.
    transactionDoneMap.set(tx, done);
}
let idbProxyTraps = {
    get (target, prop, receiver) {
        if (target instanceof IDBTransaction) {
            // Special handling for transaction.done.
            if (prop === 'done') return transactionDoneMap.get(target);
            // Make tx.store return the only store in the transaction, or undefined if there are many.
            if (prop === 'store') {
                return receiver.objectStoreNames[1] ? undefined : receiver.objectStore(receiver.objectStoreNames[0]);
            }
        }
        // Else transform whatever we get back.
        return wrap(target[prop]);
    },
    set (target, prop, value) {
        target[prop] = value;
        return true;
    },
    has (target, prop) {
        if (target instanceof IDBTransaction && (prop === 'done' || prop === 'store')) {
            return true;
        }
        return prop in target;
    }
};
function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
}
function wrapFunction(func) {
    // Due to expected object equality (which is enforced by the caching in `wrap`), we
    // only create one new func per func.
    // Cursor methods are special, as the behaviour is a little more different to standard IDB. In
    // IDB, you advance the cursor and wait for a new 'success' on the IDBRequest that gave you the
    // cursor. It's kinda like a promise that can resolve with many values. That doesn't make sense
    // with real promises, so each advance methods returns a new promise for the cursor object, or
    // undefined if the end of the cursor has been reached.
    if (getCursorAdvanceMethods().includes(func)) {
        return function() {
            for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                args[_key] = arguments[_key];
            }
            // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
            // the original object.
            func.apply(unwrap(this), args);
            return wrap(this.request);
        };
    }
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        // Calling the original function with the proxy as 'this' causes ILLEGAL INVOCATION, so we use
        // the original object.
        return wrap(func.apply(unwrap(this), args));
    };
}
function transformCachableValue(value) {
    if (typeof value === 'function') return wrapFunction(value);
    // This doesn't return, it just creates a 'done' promise for the transaction,
    // which is later returned for transaction.done (see idbObjectHandler).
    if (value instanceof IDBTransaction) cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes())) return new Proxy(value, idbProxyTraps);
    // Return the same value back if we're not going to transform it.
    return value;
}
function wrap(value) {
    // We sometimes generate multiple promises from a single IDBRequest (eg when cursoring), because
    // IDB is weird and a single IDBRequest can yield many responses, so these can't be cached.
    if (value instanceof IDBRequest) return promisifyRequest(value);
    // If we've already transformed this value before, reuse the transformed value.
    // This is faster, but it also provides object equality.
    if (transformCache.has(value)) return transformCache.get(value);
    const newValue = transformCachableValue(value);
    // Not all types are transformed.
    // These may be primitive types, so they can't be WeakMap keys.
    if (newValue !== value) {
        transformCache.set(value, newValue);
        reverseTransformCache.set(newValue, value);
    }
    return newValue;
}
const unwrap = (value)=>reverseTransformCache.get(value);
/**
 * Open a database.
 *
 * @param name Name of the database.
 * @param version Schema version.
 * @param callbacks Additional callbacks.
 */ function openDB(name, version) {
    let { blocked, upgrade, blocking, terminated } = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
        request.addEventListener('upgradeneeded', (event)=>{
            upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
        });
    }
    if (blocked) {
        request.addEventListener('blocked', (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
            event.oldVersion, event.newVersion, event));
    }
    openPromise.then((db)=>{
        if (terminated) db.addEventListener('close', ()=>terminated());
        if (blocking) {
            db.addEventListener('versionchange', (event)=>blocking(event.oldVersion, event.newVersion, event));
        }
    }).catch(()=>{});
    return openPromise;
}
/**
 * Delete a database.
 *
 * @param name Name of the database.
 */ function deleteDB(name) {
    let { blocked } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const request = indexedDB.deleteDatabase(name);
    if (blocked) {
        request.addEventListener('blocked', (event)=>blocked(// Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
            event.oldVersion, event));
    }
    return wrap(request).then(()=>undefined);
}
const readMethods = [
    'get',
    'getKey',
    'getAll',
    'getAllKeys',
    'count'
];
const writeMethods = [
    'put',
    'add',
    'delete',
    'clear'
];
const cachedMethods = new Map();
function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === 'string')) {
        return;
    }
    if (cachedMethods.get(prop)) return cachedMethods.get(prop);
    const targetFuncName = prop.replace(/FromIndex$/, '');
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (// Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))) {
        return;
    }
    const method = async function(storeName) {
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        // isWrite ? 'readwrite' : undefined gzipps better, but fails in Edge :(
        const tx = this.transaction(storeName, isWrite ? 'readwrite' : 'readonly');
        let target = tx.store;
        if (useIndex) target = target.index(args.shift());
        // Must reject if op rejects.
        // If it's a write operation, must reject if tx.done rejects.
        // Must reject with op rejection first.
        // Must resolve with op value.
        // Must handle both promises (no unhandled rejections)
        return (await Promise.all([
            target[targetFuncName](...args),
            isWrite && tx.done
        ]))[0];
    };
    cachedMethods.set(prop, method);
    return method;
}
replaceTraps((oldTraps)=>({
        ...oldTraps,
        get: (target, prop, receiver)=>getMethod(target, prop) || oldTraps.get(target, prop, receiver),
        has: (target, prop)=>!!getMethod(target, prop) || oldTraps.has(target, prop)
    }));
const advanceMethodProps = [
    'continue',
    'continuePrimaryKey',
    'advance'
];
const methodMap = {};
const advanceResults = new WeakMap();
const ittrProxiedCursorToOriginalProxy = new WeakMap();
const cursorIteratorTraps = {
    get (target, prop) {
        if (!advanceMethodProps.includes(prop)) return target[prop];
        let cachedFunc = methodMap[prop];
        if (!cachedFunc) {
            cachedFunc = methodMap[prop] = function() {
                for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                    args[_key] = arguments[_key];
                }
                advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
            };
        }
        return cachedFunc;
    }
};
async function* iterate() {
    for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
        args[_key] = arguments[_key];
    }
    // tslint:disable-next-line:no-this-assignment
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
        cursor = await cursor.openCursor(...args);
    }
    if (!cursor) return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    // Map this double-proxy back to the original, so other cursor methods work.
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while(cursor){
        yield proxiedCursor;
        // If one of the advancing methods was not called, call continue().
        cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
        advanceResults.delete(proxiedCursor);
    }
}
function isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore,
        IDBCursor
    ]) || prop === 'iterate' && instanceOfAny(target, [
        IDBIndex,
        IDBObjectStore
    ]);
}
replaceTraps((oldTraps)=>({
        ...oldTraps,
        get (target, prop, receiver) {
            if (isIteratorProp(target, prop)) return iterate;
            return oldTraps.get(target, prop, receiver);
        },
        has (target, prop) {
            return isIteratorProp(target, prop) || oldTraps.has(target, prop);
        }
    }));
;
}),
"[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BailoutToCSR", {
    enumerable: true,
    get: function() {
        return BailoutToCSR;
    }
});
const _bailouttocsr = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
function BailoutToCSR(param) {
    let { reason, children } = param;
    if (typeof window === 'undefined') {
        throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(reason), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    return children;
} //# sourceMappingURL=dynamic-bailout-to-csr.js.map
}}),
"[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "encodeURIPath", {
    enumerable: true,
    get: function() {
        return encodeURIPath;
    }
});
function encodeURIPath(file) {
    return file.split('/').map((p)=>encodeURIComponent(p)).join('/');
} //# sourceMappingURL=encode-uri-path.js.map
}}),
"[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "PreloadChunks", {
    enumerable: true,
    get: function() {
        return PreloadChunks;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _reactdom = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _encodeuripath = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)");
function PreloadChunks(param) {
    let { moduleIds } = param;
    // Early return in client compilation and only load requestStore on server side
    if (typeof window !== 'undefined') {
        return null;
    }
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    if (workStore === undefined) {
        return null;
    }
    const allFiles = [];
    // Search the current dynamic call unique key id in react loadable manifest,
    // and find the corresponding CSS files to preload
    if (workStore.reactLoadableManifest && moduleIds) {
        const manifest = workStore.reactLoadableManifest;
        for (const key of moduleIds){
            if (!manifest[key]) continue;
            const chunks = manifest[key].files;
            allFiles.push(...chunks);
        }
    }
    if (allFiles.length === 0) {
        return null;
    }
    const dplId = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '';
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: allFiles.map((chunk)=>{
            const href = workStore.assetPrefix + "/_next/" + (0, _encodeuripath.encodeURIPath)(chunk) + dplId;
            const isCss = chunk.endsWith('.css');
            // If it's stylesheet we use `precedence` o help hoist with React Float.
            // For stylesheets we actually need to render the CSS because nothing else is going to do it so it needs to be part of the component tree.
            // The `preload` for stylesheet is not optional.
            if (isCss) {
                return /*#__PURE__*/ (0, _jsxruntime.jsx)("link", {
                    // @ts-ignore
                    precedence: "dynamic",
                    href: href,
                    rel: "stylesheet",
                    as: "style"
                }, chunk);
            } else {
                // If it's script we use ReactDOM.preload to preload the resources
                (0, _reactdom.preload)(href, {
                    as: 'script',
                    fetchPriority: 'low'
                });
                return null;
            }
        })
    });
} //# sourceMappingURL=preload-chunks.js.map
}}),
"[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _dynamicbailouttocsr = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)");
const _preloadchunks = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)");
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    // Check "default" prop before accessing it, as it could be client reference proxy that could break it reference.
    // Cases:
    // mod: { default: Component }
    // mod: Component
    // mod: { default: proxy(Component) }
    // mod: proxy(Component)
    const hasDefault = mod && 'default' in mod;
    return {
        default: hasDefault ? mod.default : mod
    };
}
const defaultOptions = {
    loader: ()=>Promise.resolve(convertModule(()=>null)),
    loading: null,
    ssr: true
};
function Loadable(options) {
    const opts = {
        ...defaultOptions,
        ...options
    };
    const Lazy = /*#__PURE__*/ (0, _react.lazy)(()=>opts.loader().then(convertModule));
    const Loading = opts.loading;
    function LoadableComponent(props) {
        const fallbackElement = Loading ? /*#__PURE__*/ (0, _jsxruntime.jsx)(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        }) : null;
        // If it's non-SSR or provided a loading component, wrap it in a suspense boundary
        const hasSuspenseBoundary = !opts.ssr || !!opts.loading;
        const Wrap = hasSuspenseBoundary ? _react.Suspense : _react.Fragment;
        const wrapProps = hasSuspenseBoundary ? {
            fallback: fallbackElement
        } : {};
        const children = opts.ssr ? /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
            children: [
                typeof window === 'undefined' ? /*#__PURE__*/ (0, _jsxruntime.jsx)(_preloadchunks.PreloadChunks, {
                    moduleIds: opts.modules
                }) : null,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                    ...props
                })
            ]
        }) : /*#__PURE__*/ (0, _jsxruntime.jsx)(_dynamicbailouttocsr.BailoutToCSR, {
            reason: "next/dynamic",
            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                ...props
            })
        });
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Wrap, {
            ...wrapProps,
            children: children
        });
    }
    LoadableComponent.displayName = 'LoadableComponent';
    return LoadableComponent;
}
const _default = Loadable; //# sourceMappingURL=loadable.js.map
}}),
"[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { m: module, e: exports } = __turbopack_context__;
{
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return dynamic;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _loadable = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)"));
function dynamic(dynamicOptions, options) {
    var _mergedOptions_loadableGenerated;
    const loadableOptions = {};
    if (typeof dynamicOptions === 'function') {
        loadableOptions.loader = dynamicOptions;
    }
    const mergedOptions = {
        ...loadableOptions,
        ...options
    };
    return (0, _loadable.default)({
        ...mergedOptions,
        modules: (_mergedOptions_loadableGenerated = mergedOptions.loadableGenerated) == null ? void 0 : _mergedOptions_loadableGenerated.modules
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dynamic.js.map
}}),
}]);

//# sourceMappingURL=node_modules__pnpm_3db2edf6._.js.map