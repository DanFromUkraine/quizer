(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7452cf0e._.js",
  "static/chunks/a5ad2_next_dist_compiled_react-dom_3c988837._.js",
  "static/chunks/a5ad2_next_dist_compiled_next-devtools_index_98467e7e.js",
  "static/chunks/a5ad2_next_dist_compiled_dcf39436._.js",
  "static/chunks/a5ad2_next_dist_client_72d555b7._.js",
  "static/chunks/a5ad2_next_dist_459945d2._.js",
  "static/chunks/61dca_@swc_helpers_cjs_28edb73c._.js"
],
    source: "entry"
});
