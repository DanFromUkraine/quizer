(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_bb3d5d99._.js",
  "static/chunks/_090126b4._.js",
  "static/chunks/30910_react-icons_md_index_mjs_df4fda87._.js",
  "static/chunks/30910_react-icons_io5_index_mjs_51a8087b._.js",
  "static/chunks/node_modules__pnpm_3db2edf6._.js"
],
    source: "dynamic"
});
