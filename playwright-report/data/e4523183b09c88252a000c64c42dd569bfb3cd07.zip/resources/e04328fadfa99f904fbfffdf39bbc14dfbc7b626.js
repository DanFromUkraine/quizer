(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b2692_react-icons_bi_index_mjs_e6a2fd56._.js",
  "static/chunks/b2692_react-icons_bs_index_mjs_d9dc6687._.js",
  "static/chunks/b2692_react-icons_fa_index_mjs_290cc807._.js",
  "static/chunks/b2692_react-icons_lib_d4addfaa._.js",
  "static/chunks/node_modules__pnpm_af8014c4._.js",
  "static/chunks/app_b01165e0._.js"
],
    source: "dynamic"
});
