(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/books_page/Header/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>Header
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Header() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "heading-1",
            children: "My collections"
        }, void 0, false, {
            fileName: "[project]/src/components/books_page/Header/index.tsx",
            lineNumber: 4,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/Header/index.tsx",
        lineNumber: 3,
        columnNumber: 17
    }, this);
}
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/idUtils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getFilteredIds": ()=>getFilteredIds,
    "pickIds": ()=>pickIds
});
function pickIds(array) {
    return array.map((item)=>item.id);
}
function getFilteredIds(array, id) {
    return array.filter((prev)=>prev !== id);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/main/templates.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getTemplate": ()=>getTemplate
});
function getEmptyBookTemplate(id) {
    return {
        id,
        bookTitle: '',
        lastChangeDate: Date.now(),
        description: '',
        cardIdsOrder: [],
        explicitCardIds: [],
        shortCardIds: []
    };
}
function getEmptyCardTemplate(id) {
    return {
        id,
        type: 'explicit',
        cardTitle: '',
        childrenIds: [],
        explanation: '',
        subtitle: ''
    };
}
function getEmptyOptionTemplate(id) {
    return {
        id,
        optionTitle: '',
        isCorrect: false
    };
}
function getEmptyTermDefinitionCard(id) {
    return {
        id,
        type: 'short',
        term: '',
        definition: ''
    };
}
function getEmptyStoryTemplate(storyId) {
    return {
        id: storyId,
        bookId: '',
        timeSpentSec: 0,
        showAnswersImmediately: false,
        isCompleted: false,
        playStartDate: Date.now(),
        cardIdsOrder: [],
        explicitCardStoryIds: [],
        typeInCardStoryIds: [],
        isCorrectCardStoryIds: [],
        bookData: {
            title: '',
            description: ''
        }
    };
}
function getEmptyExplicitCardStory(id) {
    return {
        type: 'story-explicitCard',
        id,
        title: '',
        explanation: '',
        subtitle: '',
        options: [],
        currentValue: null
    };
}
function getEmptyTypeInCardStory(id) {
    return {
        type: 'story-typeInCard',
        id,
        definition: '',
        expectedInput: '',
        currentValue: '',
        answerRevealed: false
    };
}
function getEmptyIsCorrectCardStory(id) {
    return {
        type: 'story-isCorrectCard',
        id,
        term: '',
        definition: '',
        isCorrect: false,
        currentValue: null
    };
}
const templates = {
    books: getEmptyBookTemplate,
    explicitCards: getEmptyCardTemplate,
    shortCards: getEmptyTermDefinitionCard,
    options: getEmptyOptionTemplate,
    stories: getEmptyStoryTemplate,
    explicitCardStories: getEmptyExplicitCardStory,
    typeInCardStories: getEmptyTypeInCardStory,
    isCorrectCardStories: getEmptyIsCorrectCardStory
};
function getTemplate(tp, id) {
    return templates[tp](id);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/lists.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCardType": ()=>getCardType,
    "getListForInsert": ()=>getListForInsert,
    "getListForUpdate": ()=>getListForUpdate,
    "getListWhereNoSuchIds": ()=>getListWhereNoSuchIds,
    "getListWithIdsForDelete": ()=>getListWithIdsForDelete,
    "getListWithSuchIds": ()=>getListWithSuchIds,
    "getPlayCardType": ()=>getPlayCardType
});
function getListForUpdate(original, idsList) {
    return original.slice(0, idsList.length);
}
function getListWithIdsForDelete(original, idsList) {
    return idsList.slice(original.length);
}
function getListForInsert(original, idsList) {
    return original.slice(idsList.length);
}
function getListWhereNoSuchIds(originalIdsList, idsToDelete) {
    return originalIdsList.filter((id)=>!idsToDelete.includes(id));
}
function getListWithSuchIds(originalIdsList, idsToInsert) {
    return [
        ...originalIdsList,
        ...idsToInsert
    ];
}
function getCardType(param) {
    let { targetId, explicitCardIds, shortCardIds } = param;
    const idIsInExplicitCardIds = explicitCardIds.includes(targetId);
    const idIsInShortCardIds = shortCardIds.includes(targetId);
    if (idIsInExplicitCardIds) return 'explicit';
    if (idIsInShortCardIds) return 'short';
    throw "id ".concat(targetId, " is absent in both explicit card ids and short card ids");
}
function getPlayCardType(param) {
    let { targetId, explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = param;
    const idIsInExplicitCardStoryIds = explicitCardStoryIds.includes(targetId);
    const idIsInTypeInCardStoryIds = typeInCardStoryIds.includes(targetId);
    const idIsInIsCorrectCardStoryIds = isCorrectCardStoryIds.includes(targetId);
    if (idIsInExplicitCardStoryIds) return 'play-explicit';
    if (idIsInIsCorrectCardStoryIds) return 'play-isCorrect';
    if (idIsInTypeInCardStoryIds) return 'play-typeIn';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/idManagers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "booksIdsAtom": ()=>booksIdsAtom,
    "currentBookIdAtom": ()=>currentBookIdAtom,
    "currentBookIdForStoriesDialogAtom": ()=>currentBookIdForStoriesDialogAtom,
    "currentStoryIdAtom": ()=>currentStoryIdAtom,
    "deleteIdAtom": ()=>deleteIdAtom,
    "pushNewIdAtom": ()=>pushNewIdAtom,
    "storyIdsAtom": ()=>storyIdsAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/lists.ts [app-client] (ecmascript)");
;
;
const storyIdsAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])([]);
const booksIdsAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])([]);
const currentBookIdAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])('');
const currentBookIdForStoriesDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])('');
const currentStoryIdAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])('');
const pushNewIdAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (_get, set, idManager, newId)=>{
    set(idManager, (prev)=>[
            ...prev,
            newId
        ]);
});
const deleteIdAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (_get, set, param)=>{
    let { idManager, deleteId } = param;
    set(idManager, (prev)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(prev, [
            deleteId
        ]));
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/mainDbUtils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getAtomFactory": ()=>getAtomFactory,
    "getBookWithNewId": ()=>getBookWithNewId,
    "getCardWithNewOptionId": ()=>getCardWithNewOptionId,
    "getCardWithoutDeletedOptionId": ()=>getCardWithoutDeletedOptionId,
    "getNewBookWithDeletedCardId": ()=>getNewBookWithDeletedCardId
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$idUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/idUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/templates.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/lists.ts [app-client] (ecmascript)");
;
;
;
;
;
;
function getAtomFactory(storeName) {
    return (id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplate"])(storeName, id));
}
function getNewBookWithDeletedCardId(get, idToDelete) {
    /* The probability that such ids exists in both explicitCardIds and shortCardIds is so low, that should not be considered*/ const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdAtom"]);
    const { cardIdsOrder, explicitCardIds, shortCardIds, ...other } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(cardIdsOrder, [
        idToDelete
    ]);
    const newExplicitCardIdsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(explicitCardIds, [
        idToDelete
    ]);
    const newShortCardIdsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(shortCardIds, [
        idToDelete
    ]);
    return {
        ...other,
        cardIdsOrder: newCardIdsOrder,
        explicitCardIds: newExplicitCardIdsList,
        shortCardIds: newShortCardIdsList
    };
}
function getBookWithNewId(param) {
    let { cardId, cardType, bookId, get } = param;
    const { cardIdsOrder, ...other } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(cardIdsOrder, [
        cardId
    ]);
    return cardType === 'explicit' ? {
        ...other,
        cardIdsOrder: newCardIdsOrder,
        explicitCardIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(other.explicitCardIds, [
            cardId
        ])
    } : {
        ...other,
        cardIdsOrder: newCardIdsOrder,
        shortCardIds: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(other.shortCardIds, [
            cardId
        ])
    };
}
function getCardWithNewOptionId(get, cardId, optionId) {
    const cardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId);
    const prevCard = get(cardAtom);
    const newIds = [
        ...prevCard.childrenIds,
        optionId
    ];
    return {
        ...prevCard,
        childrenIds: newIds
    };
}
function getCardWithoutDeletedOptionId(get, cardId, optionId) {
    const cardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId);
    const prevCard = get(cardAtom);
    const newIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$idUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilteredIds"])(prevCard.childrenIds, optionId);
    return {
        ...prevCard,
        childrenIds: newIds
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/computeBooksAndStoriesAssociations.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>computeBooksAndStoriesAssociations
});
function computeBooksAndStoriesAssociations(stories) {
    const newEntries = stories.reduce((entries, curr)=>{
        const newEntries = entries;
        const bookId = curr.bookId;
        const bookEntryIndex = entries.findIndex((rec)=>rec[0] === bookId);
        if (bookEntryIndex === -1) {
            newEntries.push([
                bookId,
                [
                    curr.id
                ]
            ]);
        } else {
            const prevStoryIds = newEntries[bookEntryIndex][1];
            newEntries[bookEntryIndex][1] = [
                ...prevStoryIds,
                curr.id
            ];
        }
        return entries;
    }, []);
    return Object.fromEntries(newEntries);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "booksAndStoriesAssociationsAtom": ()=>booksAndStoriesAssociationsAtom,
    "booksAtomFamily": ()=>booksAtomFamily,
    "explicitCardStoriesAtomFamily": ()=>explicitCardStoriesAtomFamily,
    "explicitCardsAtomFamily": ()=>explicitCardsAtomFamily,
    "getAssociationsForBookAtomOnlyIncomplete": ()=>getAssociationsForBookAtomOnlyIncomplete,
    "isCorrectCardStoriesAtomFamily": ()=>isCorrectCardStoriesAtomFamily,
    "isInitializationFromIdbCompletedAtom": ()=>isInitializationFromIdbCompletedAtom,
    "mainDbAtom": ()=>mainDbAtom,
    "optionsAtomFamily": ()=>optionsAtomFamily,
    "shortCardsAtomFamily": ()=>shortCardsAtomFamily,
    "storiesAtomFamily": ()=>storiesAtomFamily,
    "typeInCardStoriesAtomFamily": ()=>typeInCardStoriesAtomFamily
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/mainDbUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$computeBooksAndStoriesAssociations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/computeBooksAndStoriesAssociations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const isInitializationFromIdbCompletedAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(false);
const mainDbAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])();
const booksAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('books'));
const explicitCardsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('explicitCards'));
const optionsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('options'));
const storiesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('stories'));
const shortCardsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('shortCards'));
const explicitCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('explicitCardStories'));
const typeInCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('typeInCardStories'));
const isCorrectCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFactory"])('isCorrectCardStories'));
const booksAndStoriesAssociationsAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
    const storyIds = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storyIdsAtom"]);
    const allStories = storyIds.map((storyId)=>get(storiesAtomFamily(storyId)));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$computeBooksAndStoriesAssociations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(allStories);
});
const getAssociationsForBookAtomOnlyIncomplete = (bookId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const allAssociations = get(booksAndStoriesAssociationsAtom);
        const associationsForBook = allAssociations[bookId];
        return associationsForBook.filter((storyId)=>{
            const fullStory = get(storiesAtomFamily(storyId));
            return !fullStory.isCompleted;
        });
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/BookTitle/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>BookTitle
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function BookTitle() {
    _s();
    const { bookTitle } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        className: "h3",
        children: bookTitle.length === 0 ? 'Untitled book' : bookTitle
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/BookTitle/index.tsx",
        lineNumber: 8,
        columnNumber: 17
    }, this);
}
_s(BookTitle, "f0cUaGG6dq3IwVYpp06pgT/s3AY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"]
    ];
});
_c = BookTitle;
var _c;
__turbopack_context__.k.register(_c, "BookTitle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/Description/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>BookDescription
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function BookDescription() {
    _s();
    const { description } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: "p",
        children: description.length === 0 ? 'No description yet' : description
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/Description/index.tsx",
        lineNumber: 8,
        columnNumber: 17
    }, this);
}
_s(BookDescription, "FVrOX2Y7sor/gZgAvylQiVKYQpk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"]
    ];
});
_c = BookDescription;
var _c;
__turbopack_context__.k.register(_c, "BookDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/Bread/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>Bread
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
function Bread(param) {
    let { items, className } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('span', className),
        children: items.join('/')
    }, void 0, false, {
        fileName: "[project]/src/components/general/Bread/index.tsx",
        lineNumber: 5,
        columnNumber: 16
    }, this);
}
_c = Bread;
var _c;
__turbopack_context__.k.register(_c, "Bread");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/DateBread/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>DateBread
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Bread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Bread/index.tsx [app-client] (ecmascript)");
;
;
function DateBread(param) {
    let { timeMs, className } = param;
    const date = new Date(timeMs);
    const day = date.getDate(), month = date.getMonth() + 1, year = date.getFullYear();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Bread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        items: [
            day,
            month,
            year
        ],
        className: className
    }, void 0, false, {
        fileName: "[project]/src/components/general/DateBread/index.tsx",
        lineNumber: 15,
        columnNumber: 16
    }, this);
}
_c = DateBread;
var _c;
__turbopack_context__.k.register(_c, "DateBread");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/OtherInfo/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>OtherInfo
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$DateBread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/DateBread/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function OtherInfo() {
    _s();
    const { cardsLength, lastChangeDate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-between",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "span",
                children: "".concat(cardsLength, " cards")
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/OtherInfo/index.tsx",
                lineNumber: 11,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$DateBread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                timeMs: lastChangeDate
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/OtherInfo/index.tsx",
                lineNumber: 12,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/OtherInfo/index.tsx",
        lineNumber: 10,
        columnNumber: 17
    }, this);
}
_s(OtherInfo, "1SmzZNs2XonwfkrD/CSwjSF6xtk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"]
    ];
});
_c = OtherInfo;
var _c;
__turbopack_context__.k.register(_c, "OtherInfo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/testIds.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BASE_DIALOG_TEST_IDS": ()=>BASE_DIALOG_TEST_IDS,
    "BP_TEST_IDS": ()=>BP_TEST_IDS,
    "EP_TEST_IDS": ()=>EP_TEST_IDS,
    "PP_TEST_IDS": ()=>PP_TEST_IDS,
    "SP_TEST_IDS": ()=>SP_TEST_IDS
});
const BASE_DIALOG_TEST_IDS = {
    defCloseBtn: 'Close dialog BUTTON'
};
const BP_TEST_IDS = {
    // Book page test ids
    addNewBookBtn: 'Create new empty book BUTTON',
    bookCard: {
        me: 'BOOK CARD CONTAINER',
        editBookBtn: 'edit book BUTTON',
        deleteBookBtn: 'delete book BUTTON',
        playBookBtn: 'play book BUTTON'
    },
    bookStoriesDialog: {
        me: 'BOOK STORIES DIALOG CONTAINER',
        storyCard: 'Story card related to this book',
        ...BASE_DIALOG_TEST_IDS
    },
    newStoryDialog: {
        me: 'CREATE NEW STORY DIALOG',
        isSmartModeInp: 'are cards distributed via smart way INPUT',
        areAnswersShownImmediatelyInp: 'are answers shown immediately INPUT',
        numOfExpCardsInp: 'custom param --> number of explicit cards INPUT',
        numOfNormCardsInp: 'custom param --> number of regular cards INPUT',
        numOfTypeInCards: 'custom param --> number of type in cards INPUT',
        numOfIsCorrectCards: 'custom param --> number of isCorrect cards INPUT',
        submitBtn: 'Submit params and create new story BUTTON',
        ...BASE_DIALOG_TEST_IDS
    }
};
const EP_TEST_IDS = {
    // Edit book page test ids
    bookTitleInp: 'Edit book title INPUT',
    bookDescInp: 'Edit book description INPUT',
    openDialogBtnCardsAsText: 'open dialog BUTTON to edit cards as text',
    cardsAsTextDialog: {
        me: 'EDIT CARDS AS TEXT DIALOG CONTAINER',
        mixedModeBtn: 'Choose mixed mode button',
        shortCardsOnlyModeBtn: 'Choose short cards only mode button',
        mainInp: 'Edit cards as text dialog --> main INPUT'
    },
    card: {
        me: 'CARD CONTAINER',
        deleteBtn: 'delete card BUTTON',
        explicitCardContent: {
            me: 'EXPLICIT CARD CONTENT CONTAINER',
            titleInp: 'edit explicit card --> title INPUT',
            subtitleInp: 'Edit explicit card --> subtitle INPUT',
            option: {
                me: 'OPTION',
                changeIsCorrectCheckbox: 'Edit explicit card --> edit option --> change is option correct BUTTON',
                title: 'Edit explicitCard --> edit option --> option title INPUT',
                deleteBtn: 'Edit explicit card --> delete option BUTTON'
            },
            newOptionBtn: 'Edit explicit card --> create new empty option BUTTON',
            explanationInp: 'Edit explicit card --> explanation INPUT'
        },
        shortCardContent: {
            me: 'SHORT CARD CONTENT CONTAINER',
            termInp: 'Edit short card --> term INPUT',
            definitionInp: 'Edit short card --> definition INPUT'
        }
    },
    newExpCardBtn: 'Add new empty explicit card BUTTON',
    newShortCardBtn: 'Add new empty short card BUTTON'
};
const PP_TEST_IDS = {
};
const SP_TEST_IDS = {
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/BookToolbar/EditButton/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>EditButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/md/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function EditButton() {
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookCard.editBookBtn,
        href: "/edit?bookId=".concat(id),
        className: "flex gap-1 items-center bg-amber-500 rounded-md p-1 hover:bg-amber-300 text-xs tracking-widest font-semibold duration-100 text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: "EDIT"
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/EditButton/index.tsx",
                lineNumber: 15,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdEdit"], {
                className: "text-white"
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/EditButton/index.tsx",
                lineNumber: 16,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/EditButton/index.tsx",
        lineNumber: 11,
        columnNumber: 17
    }, this);
}
_s(EditButton, "XqypXa9V4KcdjcD5vnay9WOsTKo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"]
    ];
});
_c = EditButton;
var _c;
__turbopack_context__.k.register(_c, "EditButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDerivedAtomWithIdb": ()=>getDerivedAtomWithIdb
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
;
function getDerivedAtomWithIdb(callback) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, async function(get, set) {
        for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
            args[_key - 2] = arguments[_key];
        }
        const mainDbAtom = await __turbopack_context__.r("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript, async loader)")(__turbopack_context__.i).then((r)=>r.mainDbAtom);
        const mainDb = get(mainDbAtom);
        if (typeof mainDb === 'undefined') throw new Error('main idb is undefined');
        try {
            await callback(get, set, mainDb, ...args);
        } catch (e) {
            return await Promise.reject(e);
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>getUniqueID
});
function getUniqueID() {
    const currTime = Date.now();
    return "".concat(currTime, "-").concat(crypto.randomUUID());
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/getDb.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDB": ()=>getDB
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$idb$40$8$2e$0$2e$3$2f$node_modules$2f$idb$2f$build$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/idb@8.0.3/node_modules/idb/build/index.js [app-client] (ecmascript)");
;
async function getDB(param) {
    let { dbName, upgradeAction } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$idb$40$8$2e$0$2e$3$2f$node_modules$2f$idb$2f$build$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openDB"])(dbName, 1, {
        upgrade: upgradeAction
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/dbNames.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "DB_NAMES": ()=>DB_NAMES
});
var DB_NAMES = /*#__PURE__*/ function(DB_NAMES) {
    DB_NAMES["MAIN"] = "Collections";
    DB_NAMES["HISTORY"] = "History";
    return DB_NAMES;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/createStoreEnhanced.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createObjectStoreEnhanced": ()=>createObjectStoreEnhanced
});
function createObjectStoreEnhanced(param) {
    let { db, storeName, autoIncrement } = param;
    if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName, {
            keyPath: 'id',
            autoIncrement
        });
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/mainDb.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "UPGRADE_MAIN_DB": ()=>UPGRADE_MAIN_DB
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/createStoreEnhanced.ts [app-client] (ecmascript)");
;
const UPGRADE_MAIN_DB = (database)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'books'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'explicitCards'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'shortCards'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'options'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'stories'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'explicitCardStories'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'typeInCardStories'
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$createStoreEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createObjectStoreEnhanced"])({
        db: database,
        storeName: 'isCorrectCardStories'
    });
};
_c = UPGRADE_MAIN_DB;
var _c;
__turbopack_context__.k.register(_c, "UPGRADE_MAIN_DB");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/errorHandling/catchCallbackEnhanced.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCatchCallback": ()=>getCatchCallback
});
function getCatchCallback(operationTitle) {
    return (error)=>{
        console.group('Error!');
        console.error("Couldn't complete operation: \n                        '".concat(operationTitle, "'\n                "));
        console.log("\n                        Callstack:\n                        '".concat(error.stack, "'\n                "));
        console.log("\n                        Compiler error name:\n                        '".concat(error.name, "'\n                "));
        console.log("\n                        Compiler error message:\n                        '".concat(error.message, "'\n                "));
        throw error;
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/main/factories.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addEmptyRecord": ()=>addEmptyRecord,
    "deleteRecord": ()=>deleteRecord,
    "getAllRecordsAsync": ()=>getAllRecordsAsync,
    "updateRecord": ()=>updateRecord
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandling/catchCallbackEnhanced.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/templates.ts [app-client] (ecmascript)");
;
;
function getItemTypeForLog(objectStore) {
    /* Example:
         * input is 'cards', output - 'card'.
         * Useful, when we want to specify item type (like card) in the error log */ return objectStore.toString().slice(-1);
}
async function getAllRecordsAsync(mainDb, objectStore) {
    return (await mainDb).getAll(objectStore).catch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatchCallback"])("Couldn't get all records from ".concat(objectStore, " object store from idb")));
}
function addEmptyRecord(mainDb, objectStore, id) {
    const itemTypeForLog = getItemTypeForLog(objectStore);
    const newRecord = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplate"])(objectStore, id);
    return mainDb.add(objectStore, newRecord).catch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatchCallback"])("Couldn't add empty ".concat(itemTypeForLog, " with id ").concat(id, " to ").concat(objectStore, " objectStore in idb")));
}
function updateRecord(mainDb, objectStore, newRecord) {
    const itemTypeForLog = getItemTypeForLog(objectStore);
    return mainDb.put(objectStore, newRecord).catch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatchCallback"])("Couldn't update ".concat(itemTypeForLog, " with id ").concat(newRecord.id, " in ").concat(objectStore, " objectStore in idb")));
}
function deleteRecord(mainDb, objectStore, deleteId) {
    const itemTypeForLog = getItemTypeForLog(objectStore);
    return mainDb.delete(objectStore, deleteId).catch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatchCallback"])("Couldn't delete ".concat(itemTypeForLog, " from ").concat(objectStore, " objectStore, from idb")));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/*
 * 'todo' - update/delete/getAll for explicitCardStories
 *   'todo' - update/delete/getAll for typeInCardStories
 *     'todo' - update/delete/getAll for isCorrectCardStories */ __turbopack_context__.s({
    "addEmptyBookIdb": ()=>addEmptyBookIdb,
    "addEmptyExplicitCardIdb": ()=>addEmptyExplicitCardIdb,
    "addEmptyOptionIdb": ()=>addEmptyOptionIdb,
    "addEmptyShortCardIdb": ()=>addEmptyShortCardIdb,
    "deleteBookIdb": ()=>deleteBookIdb,
    "deleteExplicitCardIdb": ()=>deleteExplicitCardIdb,
    "deleteExplicitCardStoryIdb": ()=>deleteExplicitCardStoryIdb,
    "deleteIsCorrectCardStoryIdb": ()=>deleteIsCorrectCardStoryIdb,
    "deleteOptionIdb": ()=>deleteOptionIdb,
    "deleteShortCardIdb": ()=>deleteShortCardIdb,
    "deleteStoryIdb": ()=>deleteStoryIdb,
    "deleteTypeInCardStoryIdb": ()=>deleteTypeInCardStoryIdb,
    "getAllBooksFromAsyncDb": ()=>getAllBooksFromAsyncDb,
    "getAllExplicitCardStoriesFromAsyncDb": ()=>getAllExplicitCardStoriesFromAsyncDb,
    "getAllExplicitCardsFromAsyncDb": ()=>getAllExplicitCardsFromAsyncDb,
    "getAllIsCorrectCardStoriesFromAsyncDb": ()=>getAllIsCorrectCardStoriesFromAsyncDb,
    "getAllOptionsFromAsyncDb": ()=>getAllOptionsFromAsyncDb,
    "getAllShortCardsFromAsyncDb": ()=>getAllShortCardsFromAsyncDb,
    "getAllStoriesFromAsyncDb": ()=>getAllStoriesFromAsyncDb,
    "getAllTypeInCardStoriesFromAsyncDb": ()=>getAllTypeInCardStoriesFromAsyncDb,
    "getMainDb": ()=>getMainDb,
    "updateBookIdb": ()=>updateBookIdb,
    "updateExplicitCardIdb": ()=>updateExplicitCardIdb,
    "updateExplicitCardStoryIdb": ()=>updateExplicitCardStoryIdb,
    "updateIsCorrectCardStoryIdb": ()=>updateIsCorrectCardStoryIdb,
    "updateOptionIdb": ()=>updateOptionIdb,
    "updateShortCardIdb": ()=>updateShortCardIdb,
    "updateStoryIdb": ()=>updateStoryIdb,
    "updateTypeInCardStoryIdb": ()=>updateTypeInCardStoryIdb
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$getDb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/getDb.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$dbNames$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/dbNames.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$mainDb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/mainDb.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/errorHandling/catchCallbackEnhanced.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/factories.ts [app-client] (ecmascript)");
;
;
;
;
;
function getMainDb() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$getDb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDB"])({
        dbName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$dbNames$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DB_NAMES"].MAIN,
        upgradeAction: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$mainDb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UPGRADE_MAIN_DB"]
    }).catch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$errorHandling$2f$catchCallbackEnhanced$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCatchCallback"])('Get Main db instance from IndexedDB wrapped with idb'));
}
const getAllBooksFromAsyncDb = async (asyncMainDb)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'books');
const getAllExplicitCardsFromAsyncDb = async (asyncMainDb)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'explicitCards');
const getAllShortCardsFromAsyncDb = async (asyncMainDb)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'shortCards');
const getAllOptionsFromAsyncDb = async (asyncMainDb)=>await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'options');
const getAllStoriesFromAsyncDb = async (asyncMainDb)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'stories');
const getAllExplicitCardStoriesFromAsyncDb = async (asyncMainDb)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'explicitCardStories');
const getAllTypeInCardStoriesFromAsyncDb = async (asyncMainDb)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'typeInCardStories');
const getAllIsCorrectCardStoriesFromAsyncDb = async (asyncMainDb)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllRecordsAsync"])(asyncMainDb, 'isCorrectCardStories');
const addEmptyBookIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyRecord"])(mainDb, 'books', id);
const addEmptyExplicitCardIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyRecord"])(mainDb, 'explicitCards', id);
const addEmptyShortCardIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyRecord"])(mainDb, 'shortCards', id);
const addEmptyOptionIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyRecord"])(mainDb, 'options', id);
const updateBookIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'books', newRecord);
const updateExplicitCardIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'explicitCards', newRecord);
const updateShortCardIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'shortCards', newRecord);
const updateOptionIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'options', newRecord);
const updateStoryIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'stories', newRecord);
const updateExplicitCardStoryIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'explicitCardStories', newRecord);
const updateTypeInCardStoryIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'typeInCardStories', newRecord);
const updateIsCorrectCardStoryIdb = (mainDb, newRecord)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateRecord"])(mainDb, 'isCorrectCardStories', newRecord);
const deleteBookIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'books', id);
const deleteExplicitCardIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'explicitCards', id);
const deleteShortCardIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'shortCards', id);
const deleteOptionIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'options', id);
const deleteStoryIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'stories', id);
const deleteExplicitCardStoryIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'explicitCardStories', id);
const deleteTypeInCardStoryIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'typeInCardStories', id);
const deleteIsCorrectCardStoryIdb = (mainDb, id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$factories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteRecord"])(mainDb, 'isCorrectCardStories', id);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addEmptyBookAtomHelper": ()=>addEmptyBookAtomHelper,
    "deleteBookAtomHelper": ()=>deleteBookAtomHelper,
    "getAtomFamilyDeleteAtom_NoFatherUpdate": ()=>getAtomFamilyDeleteAtom_NoFatherUpdate,
    "getAtomFamilyUpdateAtom": ()=>getAtomFamilyUpdateAtom,
    "updateBookAtomHelper": ()=>updateBookAtomHelper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/templates.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)");
;
;
;
;
function addEmptyBookAtomHelper(set, id) {
    const newBookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(id);
    const bookTemplate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$templates$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTemplate"])('books', id);
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksIdsAtom"], (prev)=>[
            ...prev,
            id
        ]);
    set(newBookAtom, bookTemplate);
}
function deleteBookAtomHelper(set, id) {
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksIdsAtom"], (prev)=>prev.filter((lastId)=>lastId !== id));
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"].remove(id);
}
function updateBookAtomHelper(set, newBook) {
    const bookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(newBook.id);
    set(bookAtom, newBook);
}
function getAtomFamilyUpdateAtom(param) {
    let { atomFamily, updateIdb } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, newItem)=>{
        await updateIdb(mainDb, newItem);
        set(atomFamily(newItem.id), newItem);
    });
}
function getAtomFamilyDeleteAtom_NoFatherUpdate(param) {
    let { atomFamily, deleteIdb } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, deleteId)=>{
        await deleteIdb(mainDb, deleteId);
        atomFamily.remove(deleteId);
    });
} /*
 * you also can create such factories for
 *
 * add empty with father ids update
 *
 * delete item with father ids update
 *
 * */ 
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/optionAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addEmptyOptionAtom": ()=>addEmptyOptionAtom,
    "addNewOptionViaTextAtom": ()=>addNewOptionViaTextAtom,
    "deleteOptionAtom": ()=>deleteOptionAtom,
    "deleteOptionViaTextAtom": ()=>deleteOptionViaTextAtom,
    "updateOptionAtom": ()=>updateOptionAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/mainDbUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/cardAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const updateOptionAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (_get, set, mainDb, newOption)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionIdb"])(mainDb, newOption);
    set((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"])(newOption.id), newOption);
});
const addEmptyOptionAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, cardId)=>{
    const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const newCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardWithNewOptionId"])(get, cardId, newId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardIdb"])(mainDb, newCard);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyOptionIdb"])(mainDb, newId);
    set((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId), newCard);
});
const deleteOptionAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, cardId, optionId)=>{
    const newCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardWithoutDeletedOptionId"])(get, cardId, optionId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteOptionIdb"])(mainDb, optionId);
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardAtom"], newCard);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"].remove(optionId);
});
const addNewOptionViaTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (_get, set, mainDb, newOption)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionIdb"])(mainDb, newOption);
    return set((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"])(newOption.id), newOption);
});
const deleteOptionViaTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (_get, _set, mainDb, optionIdToDelete)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteOptionIdb"])(mainDb, optionIdToDelete);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"].remove(optionIdToDelete);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/updateCardsFromTextReducers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDeleteAnyCardsReducerCallbackAndInitValue": ()=>getDeleteAnyCardsReducerCallbackAndInitValue,
    "getInsertAnyCardsReducerCallbackAndInitValue": ()=>getInsertAnyCardsReducerCallbackAndInitValue,
    "getReducerForDeleteOptionsAndInitData": ()=>getReducerForDeleteOptionsAndInitData,
    "getReducerForInsertOptionsAndInitData": ()=>getReducerForInsertOptionsAndInitData,
    "getShortCardOnlyDeleteReducer": ()=>getShortCardOnlyDeleteReducer,
    "getShortCardOnlyInsertReducer": ()=>getShortCardOnlyInsertReducer,
    "getShortCardOnlyUpdateCallback": ()=>getShortCardOnlyUpdateCallback,
    "getUpdateAnyCardsReducerCallbackAndInitValue": ()=>getUpdateAnyCardsReducerCallbackAndInitValue,
    "getUpdateOptionCallback": ()=>getUpdateOptionCallback,
    "updateBookAnyCardIdsAtomHelper": ()=>updateBookAnyCardIdsAtomHelper,
    "updateCardAtomHelper": ()=>updateCardAtomHelper,
    "updateShortCardsOnlyAtomHelper": ()=>updateShortCardsOnlyAtomHelper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/cardAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/lists.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/bookAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/optionAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
function getInsertAnyCardsReducerCallbackAndInitValue(set) {
    const cardIdsOrderToInsert = [];
    const explicitCardIdsToInsert = [];
    const shortCardIdsToInsert = [];
    const reducer = async (_acc, card)=>{
        const newCardId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
        cardIdsOrderToInsert.push(newCardId);
        if (card.type === 'explicit') {
            explicitCardIdsToInsert.push(newCardId);
            await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardViaText"], {
                ...card,
                id: newCardId
            });
        } else if (card.type === 'short') {
            shortCardIdsToInsert.push(newCardId);
            await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"], {
                ...card,
                id: newCardId
            });
        }
        return {
            explicitCardIdsToInsert,
            shortCardIdsToInsert,
            cardIdsOrderToInsert
        };
    };
    return [
        reducer,
        Promise.resolve({
            explicitCardIdsToInsert: [],
            shortCardIdsToInsert: [],
            cardIdsOrderToInsert: []
        })
    ];
}
function getDeleteAnyCardsReducerCallbackAndInitValue(param) {
    let { shortCardIds, explicitCardIds, set } = param;
    const explicitCardIdsToDelete = [];
    const shortCardIdsToDelete = [];
    const cardIdsOrderToDelete = [];
    const reducer = async (_acc, cardId)=>{
        const cardType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardType"])({
            targetId: cardId,
            shortCardIds,
            explicitCardIds
        });
        cardIdsOrderToDelete.push(cardId);
        if (cardType === 'explicit') {
            explicitCardIdsToDelete.push(cardId);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardViaTextAtom"], cardId);
        } else if (cardType === 'short') {
            shortCardIdsToDelete.push(cardId);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardViaTextAtom"], cardId);
        }
        return {
            explicitCardIdsToDelete,
            shortCardIdsToDelete,
            cardIdsOrderToDelete
        };
    };
    return [
        reducer,
        Promise.resolve({
            explicitCardIdsToDelete: [],
            shortCardIdsToDelete: [],
            cardIdsOrderToDelete: []
        })
    ];
}
function getUpdateAnyCardsReducerCallbackAndInitValue(param) {
    let { set, cardIdsOrder, explicitCardIds, shortCardIds } = param;
    const result = {
        explicitCardIdsToInsertAfterTypeChange: [],
        explicitCardIdsToDeleteAfterTypeChange: [],
        shortCardIdsToDeleteAfterTypeChange: [],
        shortCardIdsToInsertAfterTypeChange: []
    };
    const reducer = async (_acc, card, index)=>{
        const cardId = cardIdsOrder[index];
        const prevCardType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardType"])({
            targetId: cardIdsOrder[index],
            explicitCardIds,
            shortCardIds
        });
        const updateCard = async ()=>{
            if (card.type === 'explicit') {
                await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardViaText"], {
                    ...card,
                    id: cardId
                });
            } else {
                await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"], {
                    ...card,
                    id: cardId
                });
            }
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["incrementUpdateCountAtom"], cardId);
        };
        if (card.type === prevCardType) {
            await updateCard();
            return result;
        }
        if (card.type === 'explicit') {
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardViaTextAtom"], cardId);
            await updateCard();
            result.shortCardIdsToDeleteAfterTypeChange.push(cardId);
            result.explicitCardIdsToInsertAfterTypeChange.push(cardId);
        } else if (card.type === 'short') {
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardViaTextAtom"], cardId);
            await updateCard();
            result.explicitCardIdsToDeleteAfterTypeChange.push(cardId);
            result.shortCardIdsToInsertAfterTypeChange.push(cardId);
        }
        return result;
    };
    return [
        reducer,
        Promise.resolve({
            explicitCardIdsToInsertAfterTypeChange: [],
            explicitCardIdsToDeleteAfterTypeChange: [],
            shortCardIdsToDeleteAfterTypeChange: [],
            shortCardIdsToInsertAfterTypeChange: []
        })
    ];
}
async function updateBookAnyCardIdsAtomHelper(param) {
    let { cardIdsOrder, explicitCardIds, shortCardIds, idsToDelete: { cardIdsOrderToDelete, shortCardIdsToDelete, explicitCardIdsToDelete }, idsToInsert: { cardIdsOrderToInsert, shortCardIdsToInsert, explicitCardIdsToInsert }, idsToUpdate: { explicitCardIdsToInsertAfterTypeChange, explicitCardIdsToDeleteAfterTypeChange, shortCardIdsToInsertAfterTypeChange, shortCardIdsToDeleteAfterTypeChange }, get, set, bookId } = param;
    const bookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId);
    const prevBook = get(bookAtom);
    let newCardIdsOrder = cardIdsOrder;
    let newExplicitCardIds = explicitCardIds;
    let newShortCardIds = shortCardIds;
    if (cardIdsOrderToInsert.length > 0) {
        // Handle new cards (cards that didn't exist before)
        newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(cardIdsOrder, cardIdsOrderToInsert);
        newExplicitCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(explicitCardIds, explicitCardIdsToInsert);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(shortCardIds, shortCardIdsToInsert);
    }
    if (cardIdsOrderToDelete.length > 0) {
        // Handle cards to delete (These cards ones existed, but now they will be deleted)
        newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(cardIdsOrder, cardIdsOrderToDelete);
        newExplicitCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(explicitCardIds, explicitCardIdsToDelete);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(shortCardIds, shortCardIdsToDelete);
    }
    if (explicitCardIdsToInsertAfterTypeChange.length > 0) {
        // Previously card at this index was of type term-definition, but now at this index card of type explicit
        newExplicitCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(newExplicitCardIds, explicitCardIdsToInsertAfterTypeChange);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(newShortCardIds, shortCardIdsToDeleteAfterTypeChange);
    }
    if (shortCardIdsToInsertAfterTypeChange.length > 0) {
        // Previously card at this index was of type explicit, but now at this index card of type term-definition
        newExplicitCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(newExplicitCardIds, explicitCardIdsToDeleteAfterTypeChange);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(newShortCardIds, shortCardIdsToInsertAfterTypeChange);
    }
    await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtom"], {
        ...prevBook,
        cardIdsOrder: newCardIdsOrder,
        explicitCardIds: newExplicitCardIds,
        shortCardIds: newShortCardIds
    });
}
function getReducerForInsertOptionsAndInitData(set) {
    const newOptionIds = [];
    return [
        async (_acc, param)=>{
            let { optionTitle, isCorrect } = param;
            const newOptionId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
            newOptionIds.push(newOptionId);
            await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionAtom"], {
                id: newOptionId,
                optionTitle,
                isCorrect
            });
            return newOptionIds;
        },
        Promise.resolve([])
    ];
}
function getReducerForDeleteOptionsAndInitData(set) {
    const optionIdsToDelete = [];
    return [
        async (_acc, optionId)=>{
            optionIdsToDelete.push(optionId);
            await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteOptionViaTextAtom"], optionId);
            return optionIdsToDelete;
        },
        Promise.resolve([])
    ];
}
function getUpdateOptionCallback(param) {
    let { optionIds, set } = param;
    return async (option, index)=>{
        const optionId = optionIds[index];
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionAtom"], {
            id: optionId,
            ...option
        });
    };
}
async function updateCardAtomHelper(param) {
    let { optionIdsToInsert, optionIdsToDelete, optionIds, set, card: { options: _options, ...usefulCardData } } = param;
    let newOptionIds = optionIds;
    if (optionIdsToInsert.length > 0) {
        newOptionIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(optionIds, optionIdsToInsert);
    } else if (optionIdsToDelete.length > 0) {
        newOptionIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(optionIds, optionIdsToDelete);
    }
    await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardAtom"], {
        ...usefulCardData,
        childrenIds: newOptionIds
    });
}
function getShortCardOnlyUpdateCallback(param) {
    let { set, shortCardIds } = param;
    return async (card, i)=>{
        const cardId = shortCardIds[i];
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"], {
            ...card,
            id: cardId
        });
        set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["incrementUpdateCountAtom"], cardId);
    };
}
function getShortCardOnlyInsertReducer(set) {
    const newIdsToInsert = [];
    const reducer = async (_acc, card)=>{
        const newId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
        newIdsToInsert.push(newId);
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"], {
            ...card,
            id: newId
        });
        return newIdsToInsert;
    };
    return [
        reducer,
        Promise.resolve([])
    ];
}
function getShortCardOnlyDeleteReducer(set) {
    const idsToDelete = [];
    const reducer = async (_acc, cardIdToDelete)=>{
        idsToDelete.push(cardIdToDelete);
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardViaTextAtom"], cardIdToDelete);
        return idsToDelete;
    };
    return [
        reducer,
        Promise.resolve([])
    ];
}
async function updateShortCardsOnlyAtomHelper(param) {
    let { cardIdsToInsert, cardIdsToDelete, get, set, bookId } = param;
    const bookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId);
    const { cardIdsOrder, shortCardIds, ...other } = get(bookAtom);
    let newCardIdsOrder = cardIdsOrder;
    let newShortCardIds = shortCardIds;
    const areAnyNew = cardIdsToInsert.length > 0;
    const areAnyDeleted = cardIdsToDelete.length > 0;
    const updateBook = async ()=>{
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtom"], {
            ...other,
            cardIdsOrder: newCardIdsOrder,
            shortCardIds: newShortCardIds
        });
    };
    if (areAnyNew) {
        newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(cardIdsOrder, cardIdsToInsert);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithSuchIds"])(shortCardIds, cardIdsToInsert);
    }
    if (areAnyDeleted) {
        newCardIdsOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(cardIdsOrder, cardIdsToDelete);
        newShortCardIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWhereNoSuchIds"])(shortCardIds, cardIdsToDelete);
    }
    if (areAnyNew || areAnyDeleted) {
        await updateBook();
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/errors.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CARD_TYPE_UNKNOWN": ()=>CARD_TYPE_UNKNOWN
});
const CARD_TYPE_UNKNOWN = "Error: Couldn't figure out the type of card (explicit, or short)";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/cardsAsText/helpers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCardSeparator": ()=>getCardSeparator,
    "getCardTypeFromText": ()=>getCardTypeFromText,
    "getFilterRuleToDeleteCardsWithEmptyTitle": ()=>getFilterRuleToDeleteCardsWithEmptyTitle,
    "getOptionsAsText": ()=>getOptionsAsText,
    "getProcessedCards": ()=>getProcessedCards,
    "getProcessedExplicitCard": ()=>getProcessedExplicitCard,
    "getProcessedOptions": ()=>getProcessedOptions,
    "getProcessedShortCard": ()=>getProcessedShortCard,
    "getProcessedShortCardOnly": ()=>getProcessedShortCardOnly
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$errors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/errors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
;
;
function getProcessedShortCardOnly(cardText) {
    if (typeof cardText === 'undefined') return;
    const cleanValue = getValCleanFromSpecSigns(cardText);
    if (cleanValue.length === 0) return;
    let term = '';
    let definition = '';
    try {
        const [t, d] = cardText.split(/ - | – |: /);
        term = t;
        definition = d;
    } catch (e) {}
    return {
        type: 'short',
        term,
        definition
    };
}
const RULES = {
    FULL_CARD_MARKER: '&&',
    SUBTITLE_MARKER: '&s',
    DEFAULT_OPTION_MARKER: '%%',
    EXPLANATION_MARKER: '&e',
    SHORT_CARD_MARKER: '@@',
    OPTION_CORRECT_MARKER: '%correct%'
};
function getCardSeparator() {
    return /(&&|@@)/g;
}
function getAllRulesAsRegExp() {
    return /&&|%%|&s|&e|@@/g;
}
function splitByIndex(str, index) {
    return [
        str.slice(0, index),
        str.slice(index)
    ];
}
function extractTarget(stringWithTarget, regex) {
    const [_partialWithoutTarget, partialWithTarget_UNSAFE] = typeof regex !== 'undefined' ? stringWithTarget.split(regex) : splitByIndex(stringWithTarget, 0);
    const partialWithTarget = partialWithTarget_UNSAFE || '';
    const [targetString] = partialWithTarget.split(getAllRulesAsRegExp());
    return removeSpecialSymbols(targetString).trim();
}
function removeSpecialSymbols(string) {
    const ALL_SPECIAL_SYMBOLS = /\\n|\\t/g;
    return string.replaceAll(ALL_SPECIAL_SYMBOLS, '');
}
function getProcessedOptions(optionText) {
    const isCorrect = optionText.includes(RULES.OPTION_CORRECT_MARKER);
    const optionTitleDirty = isCorrect ? optionText.replace(RULES.OPTION_CORRECT_MARKER, '') : optionText;
    const optionTitleClear = removeSpecialSymbols(optionTitleDirty).trim();
    return {
        isCorrect,
        optionTitle: optionTitleClear
    };
}
function getProcessedShortCard(shortCardText) {
    const [term, definition] = shortCardText.split(/ - | – |: /);
    return {
        type: 'short',
        term: term || '',
        definition: definition || '' // definition can be undefined, so we need such solution, so in further checks program doesn't lay down
    };
}
function getClearOptionTextList(explicitCardText) {
    const optionsUnfiltered = explicitCardText.split(/(%%)/);
    const resultOptions = [];
    let prevItemWasOptSymbol = false;
    for(let i = 1; i < optionsUnfiltered.length; i++){
        const prevItem = optionsUnfiltered[i - 1];
        if (prevItem === '%%') {
            const optWithRubbish = optionsUnfiltered[i];
            const [option] = optWithRubbish.split(/&e|&s/);
            resultOptions.push(option);
            prevItemWasOptSymbol = false;
        }
    }
    return resultOptions;
}
function getProcessedExplicitCard(explicitCardText) {
    const cardTitle = extractTarget(explicitCardText);
    const subtitle = extractTarget(explicitCardText, RULES.SUBTITLE_MARKER);
    const explanation = extractTarget(explicitCardText, RULES.EXPLANATION_MARKER);
    const textOptionList = getClearOptionTextList(explicitCardText);
    return {
        type: 'explicit',
        cardTitle,
        subtitle,
        explanation,
        options: textOptionList.map((optionText)=>getProcessedOptions(optionText))
    };
}
function getValCleanFromSpecSigns(val) {
    return val.replaceAll(/(@@)|(&&)|(\n)|(\t)/g, '').trim();
}
function getCardTypeFromText(param) {
    let { fullArray, index } = param;
    const prevEl = fullArray[index - 1];
    if (prevEl.includes('@@')) {
        return 'short';
    } else if (prevEl.includes('&&')) {
        return 'explicit';
    } else {
        throw __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$errors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CARD_TYPE_UNKNOWN"];
    }
}
function getProcessedCards(param) {
    let { currentValue, index, fullArray } = param;
    if (typeof currentValue === 'undefined') return;
    const cleanValue = getValCleanFromSpecSigns(currentValue);
    if (cleanValue.length === 0) return;
    const cardType = getCardTypeFromText({
        fullArray,
        index
    });
    if (cardType === 'short') {
        return getProcessedShortCard(cleanValue);
    } else {
        return getProcessedExplicitCard(cleanValue);
    }
}
function getFilterRuleToDeleteCardsWithEmptyTitle() {
    return (anyCard)=>{
        if (anyCard.type === 'explicit') {
            return anyCard.cardTitle.length > 0;
        } else if (anyCard.type === 'short') {
            if (typeof anyCard.term === 'undefined' || typeof anyCard.definition === 'undefined') return false;
            return anyCard.term.length > 0 && anyCard.definition.length > 0;
        } else {
            throw 'Cards from text array includes card without type (type should be "explicit", or "short"))';
        }
    };
}
function getOptionsAsText(optionsIds, get) {
    return optionsIds.map((optionId)=>{
        const { optionTitle, isCorrect } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"])(optionId));
        return "\n 	 %% ".concat(isCorrect ? '%correct%' : '', " ").concat(optionTitle);
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/cardsAsText/fromTextToCards.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 'todo' - need to add support for other formats.
// 'todo' - rewrite in AssemblyScript, to optimize it
// 'todo' - add change flag, to show renderer, if a component actually needs render.
// 'todo' - need to add support for other formats.
// 'todo' - rewrite in AssemblyScript, to optimize it
// 'todo' - add change flag, to show renderer, if a component actually needs render.
__turbopack_context__.s({
    "parseTextIntoAnyCardsArray": ()=>parseTextIntoAnyCardsArray,
    "parseTextIntoOnlyShortCardsArray": ()=>parseTextIntoOnlyShortCardsArray
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/cardsAsText/helpers.ts [app-client] (ecmascript)");
;
function parseTextIntoAnyCardsArray(targetText) {
    const cardsUnprocessed = targetText.split((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardSeparator"])());
    return cardsUnprocessed.map((cardText, i, arr)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProcessedCards"])({
            currentValue: cardText,
            index: i,
            fullArray: arr
        })).filter((val)=>typeof val !== 'undefined').filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilterRuleToDeleteCardsWithEmptyTitle"])());
}
function parseTextIntoOnlyShortCardsArray(targetText) {
    const cardsUnprocessed = targetText.split(/\n/g);
    return cardsUnprocessed.map((shortCardText)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProcessedShortCardOnly"])(shortCardText)).filter((val)=>typeof val !== 'undefined').filter((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilterRuleToDeleteCardsWithEmptyTitle"])());
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/cardAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* 'todo' - This file is kinda huge. Need to divide it into small peaces
 */ __turbopack_context__.s({
    "addEmptyExplicitCardAtom": ()=>addEmptyExplicitCardAtom,
    "addEmptyTermShortCard": ()=>addEmptyTermShortCard,
    "deleteExplicitCardAtom": ()=>deleteExplicitCardAtom,
    "deleteExplicitCardViaTextAtom": ()=>deleteExplicitCardViaTextAtom,
    "deleteShortCardAtom": ()=>deleteShortCardAtom,
    "deleteShortCardViaTextAtom": ()=>deleteShortCardViaTextAtom,
    "incrementUpdateCountAtom": ()=>incrementUpdateCountAtom,
    "updateAnyCardsFromTextAtom": ()=>updateAnyCardsFromTextAtom,
    "updateCardViaTextAtomFamily": ()=>updateCardViaTextAtomFamily,
    "updateExplicitCardAtom": ()=>updateExplicitCardAtom,
    "updateExplicitCardViaText": ()=>updateExplicitCardViaText,
    "updateOnlyShortCardsFromTextAtom": ()=>updateOnlyShortCardsFromTextAtom,
    "updateShortCardAtom": ()=>updateShortCardAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/mainDbUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/lists.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/updateCardsFromTextReducers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$fromTextToCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/cardsAsText/fromTextToCards.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/optionAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
const updateCardViaTextAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((_cardId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(0));
const incrementUpdateCountAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, cardId)=>{
    set(updateCardViaTextAtomFamily(cardId), (prev)=>prev + 1);
});
const addEmptyExplicitCardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb)=>{
    const cardId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdAtom"]);
    const newBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBookWithNewId"])({
        get,
        bookId,
        cardId,
        cardType: 'explicit'
    });
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookIdb"])(mainDb, newBook);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyExplicitCardIdb"])(mainDb, cardId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtomHelper"])(set, newBook);
});
const addEmptyTermShortCard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb)=>{
    const cardId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdAtom"]);
    const newBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBookWithNewId"])({
        get,
        bookId,
        cardId,
        cardType: 'short'
    });
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookIdb"])(mainDb, newBook);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyShortCardIdb"])(mainDb, cardId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtomHelper"])(set, newBook);
});
const updateExplicitCardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardIdb"]
});
const updateShortCardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardIdb"]
});
const deleteExplicitCardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, cardId)=>{
    const newBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewBookWithDeletedCardId"])(get, cardId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookIdb"])(mainDb, newBook);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardIdb"])(mainDb, cardId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtomHelper"])(set, newBook);
    await deleteOptionsOnCardDeleteAtomHelper(get, set, cardId);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"].remove(cardId);
});
const deleteShortCardAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, cardId)=>{
    const newBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$mainDbUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewBookWithDeletedCardId"])(get, cardId);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookIdb"])(mainDb, newBook);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardIdb"])(mainDb, cardId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtomHelper"])(set, newBook);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"].remove(cardId);
});
const deleteExplicitCardViaTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyDeleteAtom_NoFatherUpdate"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"],
    deleteIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardIdb"]
});
const deleteShortCardViaTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyDeleteAtom_NoFatherUpdate"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"],
    deleteIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardIdb"]
});
const updateExplicitCardViaText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, async (get, set, newCard)=>{
    const { childrenIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(newCard.id));
    const options = newCard.options;
    const asyncOptionIdsToInsert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForInsert"])(options, childrenIds).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReducerForInsertOptionsAndInitData"])(set));
    const asyncOptionIdsToDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithIdsForDelete"])(options, childrenIds).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getReducerForDeleteOptionsAndInitData"])(set));
    const asyncVoidListToUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForUpdate"])(options, childrenIds).map((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUpdateOptionCallback"])({
        optionIds: childrenIds,
        set
    }));
    const [optionIdsToInsert, optionIdsToDelete] = await Promise.all([
        asyncOptionIdsToInsert,
        asyncOptionIdsToDelete,
        asyncVoidListToUpdate
    ]);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCardAtomHelper"])({
        optionIds: childrenIds,
        optionIdsToInsert,
        optionIdsToDelete,
        card: newCard,
        set
    });
});
const updateAnyCardsFromTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, async (get, set, cardsText)=>{
    const cardsArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$fromTextToCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTextIntoAnyCardsArray"])(cardsText);
    const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdAtom"]);
    const { cardIdsOrder, shortCardIds, explicitCardIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const asyncIdsToInsert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForInsert"])(cardsArray, cardIdsOrder).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInsertAnyCardsReducerCallbackAndInitValue"])(set));
    const asyncIdsToDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithIdsForDelete"])(cardsArray, cardIdsOrder).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDeleteAnyCardsReducerCallbackAndInitValue"])({
        shortCardIds,
        explicitCardIds,
        set
    }));
    const asyncIdsToUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForUpdate"])(cardsArray, cardIdsOrder).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUpdateAnyCardsReducerCallbackAndInitValue"])({
        set,
        cardIdsOrder,
        shortCardIds,
        explicitCardIds
    }));
    const [idsToInsert, idsToDelete, idsToUpdate] = await Promise.all([
        asyncIdsToInsert,
        asyncIdsToDelete,
        asyncIdsToUpdate
    ]);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAnyCardIdsAtomHelper"])({
        cardIdsOrder,
        shortCardIds,
        explicitCardIds,
        idsToDelete,
        idsToInsert,
        bookId,
        get,
        set,
        idsToUpdate
    });
});
const updateOnlyShortCardsFromTextAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, async (get, set, cardsText)=>{
    const cardsArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$cardsAsText$2f$fromTextToCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTextIntoOnlyShortCardsArray"])(cardsText);
    const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdAtom"]);
    const { shortCardIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const asyncVoidListToUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForUpdate"])(cardsArray, shortCardIds).map((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShortCardOnlyUpdateCallback"])({
        set,
        shortCardIds
    }));
    const asyncIdsToInsert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListForInsert"])(cardsArray, shortCardIds).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShortCardOnlyInsertReducer"])(set));
    const asyncIdsToDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$lists$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getListWithIdsForDelete"])(cardsArray, shortCardIds).reduce(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getShortCardOnlyDeleteReducer"])(set));
    const [cardIdsToInsert, cardIdsToDelete] = await Promise.all([
        asyncIdsToInsert,
        asyncIdsToDelete,
        asyncVoidListToUpdate
    ]);
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$updateCardsFromTextReducers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardsOnlyAtomHelper"])({
        cardIdsToDelete,
        cardIdsToInsert,
        get,
        set,
        bookId
    });
});
async function deleteOptionsOnCardDeleteAtomHelper(get, set, cardId) {
    const { childrenIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId));
    for await (const optionId of childrenIds){
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteOptionAtom"], cardId, optionId);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/bookAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addEmptyBookAtom": ()=>addEmptyBookAtom,
    "deleteBookAtom": ()=>deleteBookAtom,
    "updateBookAtom": ()=>updateBookAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/cardAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const addEmptyBookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (_get, set, mainDb)=>{
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyBookIdb"])(mainDb, id);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyBookAtomHelper"])(set, id);
});
async function deleteCardsOnBookDeleteAtomHelper(get, set, bookId) {
    const { explicitCardIds, shortCardIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    for await (const cardId of explicitCardIds){
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardAtom"], cardId);
    }
    for await (const cardId of shortCardIds){
        await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteShortCardAtom"], cardId);
    }
}
const deleteBookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, bookId)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBookIdb"])(mainDb, bookId);
    await deleteCardsOnBookDeleteAtomHelper(get, set, bookId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBookAtomHelper"])(set, bookId);
});
const updateBookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookIdb"]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/BookToolbar/DeleteButton/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>DeleteButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/md/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/bookAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function DeleteButton() {
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    const deleteBook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteBookAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdDelete"], {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookCard.deleteBookBtn,
        onClick: ()=>deleteBook(id),
        className: "text-gray-500 hover:text-red-600 duration-100 text-3xl"
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/DeleteButton/index.tsx",
        lineNumber: 14,
        columnNumber: 17
    }, this);
}
_s(DeleteButton, "CqKd1x4lsOyRhagQ2bDCxMgJuO0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"]
    ];
});
_c = DeleteButton;
var _c;
__turbopack_context__.k.register(_c, "DeleteButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/BookToolbar/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>Toolbar
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$EditButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/BookToolbar/EditButton/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$DeleteButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/BookToolbar/DeleteButton/index.tsx [app-client] (ecmascript)");
;
;
;
function Toolbar() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex w-full justify-between items-center mb-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$EditButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/index.tsx",
                lineNumber: 7,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$DeleteButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/index.tsx",
                lineNumber: 8,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/BookToolbar/index.tsx",
        lineNumber: 6,
        columnNumber: 17
    }, this);
}
_c = Toolbar;
var _c;
__turbopack_context__.k.register(_c, "Toolbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "actionNeededDataAtom": ()=>actionNeededDataAtom,
    "closeActionNeededDialogAtom": ()=>closeActionNeededDialogAtom,
    "createDialogWithInfoPair": ()=>createDialogWithInfoPair,
    "dialogVisibilityFamilyAtom": ()=>dialogVisibilityFamilyAtom,
    "hideDialogAtom": ()=>hideDialogAtom,
    "openActionNeededDialogAtom": ()=>openActionNeededDialogAtom,
    "openDialogAtom": ()=>openDialogAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla/utils.mjs [app-client] (ecmascript)");
;
;
const dialogVisibilityFamilyAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atomFamily"])((_id)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(false));
const openDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (_get, set, dialogName)=>{
    set(dialogVisibilityFamilyAtom(dialogName), true);
});
const hideDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, dialogName)=>{
    const prevVisibility = get(dialogVisibilityFamilyAtom(dialogName));
    if (prevVisibility !== false) set(dialogVisibilityFamilyAtom(dialogName), false);
});
const [actionNeededDataAtom, openActionNeededDialogAtom, closeActionNeededDialogAtom] = createDialogWithInfoPair({
    dialogName: 'actionNeeded',
    initData: {
        message: '',
        onApprove: ()=>{}
    },
    getDialogData (_get, _set, actionInfo) {
        return actionInfo;
    }
});
function createDialogWithInfoPair(param) {
    let { dialogName, initData, getDialogData } = param;
    const dialogDataAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(initData);
    const showDataReachDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, function(get, set) {
        for(var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++){
            args[_key - 2] = arguments[_key];
        }
        set(dialogDataAtom, getDialogData(get, set, ...args));
        set(openDialogAtom, dialogName);
    });
    const hideDataReachDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (_get, set)=>{
        set(hideDialogAtom, dialogName);
        set(dialogDataAtom, initData);
    });
    return [
        dialogDataAtom,
        showDataReachDialogAtom,
        hideDataReachDialogAtom
    ];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/snackbarAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "showSnackbarAtom": ()=>showSnackbarAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
;
;
const showSnackbarAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, param)=>{
    let { snackbarName, timeMS } = param;
    const isSnackbarAlreadyShown = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dialogVisibilityFamilyAtom"])(snackbarName));
    if (isSnackbarAlreadyShown) return;
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openDialogAtom"], snackbarName);
    setTimeout(()=>{
        set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideDialogAtom"], snackbarName);
    }, timeMS);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/emptyObjects.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "EMPTY_NEW_STORY_TEMPORARY_INFO": ()=>EMPTY_NEW_STORY_TEMPORARY_INFO,
    "EMPTY_STORY_SETTINGS_ATOM": ()=>EMPTY_STORY_SETTINGS_ATOM
});
const EMPTY_NEW_STORY_TEMPORARY_INFO = {
    maxNumOfExplicitCards: 0,
    maxNumOfNormalCards: 0,
    maxNumOfTypeInCards: 0,
    maxNumOfIsCorrectCards: 0
};
const EMPTY_STORY_SETTINGS_ATOM = {
    isSmartMode: true,
    showAnswersImmediately: false,
    numOfExplicitCards: 0,
    numOfNormalCards: 0,
    numOfTypeInCards: 0,
    numOfIsCorrectCards: 0,
    bookId: ''
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/fisherYatesShafle.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>shuffleList
});
function shuffleList(array) {
    const newList = [
        ...array
    ];
    for(let i = newList.length - 1; i > 0; i--){
        const j = Math.floor(Math.random() * (i + 1));
        [newList[i], newList[j]] = [
            newList[j],
            newList[i]
        ];
    }
    return newList;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createNewStory/helpers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "fiftyFifty": ()=>fiftyFifty,
    "getAllExplicitCards": ()=>getAllExplicitCards,
    "getAllShortCards": ()=>getAllShortCards,
    "getCardsForAlgorithm": ()=>getCardsForAlgorithm,
    "getCorrectOptionFromOptions": ()=>getCorrectOptionFromOptions,
    "getExplicitCardStory": ()=>getExplicitCardStory,
    "getOption": ()=>getOption,
    "getOptionsHeap": ()=>getOptionsHeap,
    "getRandomItemsFromList": ()=>getRandomItemsFromList,
    "getRandomOptAvoidingCurr": ()=>getRandomOptAvoidingCurr
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fisherYatesShafle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/fisherYatesShafle.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
;
;
;
function getOption(param) {
    let { get, optionId } = param;
    const { optionTitle, isCorrect, id } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"])(optionId));
    return {
        title: optionTitle,
        isCorrect
    };
}
function getExplicitCardStory(param) {
    let { get, cardId } = param;
    const { cardTitle, explanation, childrenIds, subtitle } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId));
    return {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(),
        currentValue: null,
        type: 'story-explicitCard',
        title: cardTitle,
        subtitle,
        explanation,
        options: childrenIds.map((optionId)=>getOption({
                get,
                optionId
            }))
    };
}
function getAllExplicitCards(param) {
    let { get, explicitCardIds } = param;
    return explicitCardIds.map((cardId)=>getExplicitCardStory({
            get,
            cardId
        }));
}
function getAllShortCards(param) {
    let { get, shortCardIds } = param;
    return shortCardIds.map((cardId)=>get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"])(cardId)));
}
function getOptionsHeap(param) {
    let { playExplicitCards, shortCards } = param;
    const optionsFromExpCards = playExplicitCards.flatMap((param)=>{
        let { options } = param;
        return options.map((opt)=>opt.title);
    });
    const optionsFromShortCards = shortCards.map((param)=>{
        let { definition } = param;
        return definition;
    });
    return [
        ...optionsFromExpCards,
        ...optionsFromShortCards
    ];
}
function fiftyFifty() {
    return Math.random() < 0.5;
}
function getRandomItemsFromList(list, n) {
    const shuffledList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fisherYatesShafle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(list);
    return shuffledList.slice(0, n);
}
function getCardsForAlgorithm(param) {
    let { requiredNum, shortCards, playExplicitCards } = param;
    const shortCardsNeeded = Math.min(requiredNum, shortCards.length);
    const shortCardsForAlgo = getRandomItemsFromList(shortCards, shortCardsNeeded);
    const explicitNeeded = Math.max(0, requiredNum - shortCards.length);
    const explicitCardsForAlgo = explicitNeeded > 0 ? getRandomItemsFromList(playExplicitCards, Math.min(explicitNeeded, playExplicitCards.length)) : [];
    return [
        shortCardsForAlgo,
        explicitCardsForAlgo
    ];
}
function getRandomOptAvoidingCurr(param) {
    let { allOptions, targetOpt } = param;
    const anArrayWithoutCurrentDefinition = allOptions.filter((currOpt)=>currOpt !== targetOpt);
    return getRandomItem(anArrayWithoutCurrentDefinition);
}
function getRandomItem(array) {
    const randomIndex = Math.floor(Math.random() * array.length);
    return array[randomIndex];
}
function getCorrectOptionFromOptions(options) {
    const correctOption = options.find((option)=>option.isCorrect);
    if (!correctOption) throw new Error('No correct option in an explicit card');
    return correctOption;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createNewStory/getNormalCards.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getNormalCards": ()=>getNormalCards
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/helpers.ts [app-client] (ecmascript)");
;
;
function getNormalCards(param) {
    let { requiredNum, shortCards, allOptions } = param;
    const shortCardsForAlgo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRandomItemsFromList"])(shortCards, requiredNum);
    return shortCardsForAlgo.map((param)=>{
        let { term, definition, id } = param;
        const options = Array(4);
        const corrOptInd = Math.floor(Math.random() * 4);
        options[corrOptInd] = {
            isCorrect: true,
            title: definition
        };
        for(let i = 0; i < options.length; i++){
            if (i === corrOptInd) continue;
            const randomOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRandomOptAvoidingCurr"])({
                allOptions,
                targetOpt: definition
            });
            options[i] = {
                isCorrect: false,
                title: randomOption
            };
        }
        return {
            id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(),
            type: 'story-explicitCard',
            currentValue: null,
            title: term,
            options,
            explanation: '',
            subtitle: ''
        };
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createNewStory/getTypeInCards.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getTypeInCards": ()=>getTypeInCards
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
;
;
function getTypeInCard(param) {
    let { def, expInp } = param;
    return {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(),
        type: 'story-typeInCard',
        currentValue: '',
        answerRevealed: false,
        definition: def,
        expectedInput: expInp
    };
}
function getTypeInCards(param) {
    let { requiredNum, playExplicitCards, shortCards } = param;
    const [shortCardsForAlgo, explicitCardsForAlgo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardsForAlgorithm"])({
        playExplicitCards,
        requiredNum,
        shortCards
    });
    const typeInCardsResult = [];
    shortCardsForAlgo.forEach((param)=>{
        let { term, definition } = param;
        typeInCardsResult.push(getTypeInCard({
            def: definition,
            expInp: term
        }));
    });
    explicitCardsForAlgo.forEach((param)=>{
        let { title, options } = param;
        typeInCardsResult.push(getTypeInCard({
            def: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCorrectOptionFromOptions"])(options).title,
            expInp: title
        }));
    });
    return typeInCardsResult;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createNewStory/getIsCorrectCards.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getIsCorrectCards": ()=>getIsCorrectCards
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
;
;
function getIsCorrectCards(param) {
    let { requiredNum, playExplicitCards, shortCards, allOptions } = param;
    const isCorrectCards = [];
    const [shortCardsForAlgo, explicitCardsForAlgo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCardsForAlgorithm"])({
        requiredNum,
        playExplicitCards,
        shortCards
    });
    shortCardsForAlgo.forEach((param)=>{
        let { term, definition } = param;
        const isCorrect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fiftyFifty"])();
        if (isCorrect) {
            isCorrectCards.push(getCorrectCard({
                t: term,
                d: definition
            }));
        } else {
            isCorrectCards.push(getIncorrectCard({
                t: term,
                d: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRandomOptAvoidingCurr"])({
                    allOptions,
                    targetOpt: definition
                })
            }));
        }
    });
    explicitCardsForAlgo.forEach((param)=>{
        let { title, options } = param;
        const isCorrect = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fiftyFifty"])();
        const correctOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCorrectOptionFromOptions"])(options);
        if (isCorrect) {
            isCorrectCards.push(getCorrectCard({
                t: title,
                d: correctOption.title
            }));
        } else {
            isCorrectCards.push(getIncorrectCard({
                t: title,
                d: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRandomOptAvoidingCurr"])({
                    allOptions,
                    targetOpt: correctOption.title
                })
            }));
        }
    });
    return isCorrectCards;
}
function getIncorrectCard(param) {
    let { t, d } = param;
    return {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(),
        type: 'story-isCorrectCard',
        currentValue: null,
        isCorrect: false,
        term: t,
        definition: d
    };
}
function getCorrectCard(param) {
    let { t, d } = param;
    return {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(),
        type: 'story-isCorrectCard',
        currentValue: null,
        isCorrect: true,
        term: t,
        definition: d
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/explicitCardStoryAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "deleteExplicitCardStoryAtom": ()=>deleteExplicitCardStoryAtom,
    "updateExplicitCardStoryAtom": ()=>updateExplicitCardStoryAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)");
;
;
;
const updateExplicitCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardStoryIdb"]
});
const deleteExplicitCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyDeleteAtom_NoFatherUpdate"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"],
    deleteIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardStoryIdb"]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/typeInCardStoryAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "deleteTypeInCardStoryAtom": ()=>deleteTypeInCardStoryAtom,
    "updateTypeInCardStoryAtom": ()=>updateTypeInCardStoryAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)");
;
;
;
const updateTypeInCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateTypeInCardStoryIdb"]
});
const deleteTypeInCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyDeleteAtom_NoFatherUpdate"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"],
    deleteIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteTypeInCardStoryIdb"]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/isCorrectCardStoryAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* 'todo' - I see there's some code duplications.
1. updateIsCorrectCardStoryAtom - updateExplicitCardStoryAtom - updateTypeInCardStoryAtom - updateExplicitCardAtom - updateShortCardAtom
2. deleteIsCorrectCardStoryAtom - deleteExplicitCardStoryAtom - deleteTypeInCardStoryAtom

*  */ __turbopack_context__.s({
    "deleteIsCorrectCardStoryAtom": ()=>deleteIsCorrectCardStoryAtom,
    "updateIsCorrectCardStoryAtom": ()=>updateIsCorrectCardStoryAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/helpers.ts [app-client] (ecmascript)");
;
;
;
const updateIsCorrectCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyUpdateAtom"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"],
    updateIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateIsCorrectCardStoryIdb"]
});
const deleteIsCorrectCardStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAtomFamilyDeleteAtom_NoFatherUpdate"])({
    atomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"],
    deleteIdb: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteIsCorrectCardStoryIdb"]
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createNewStory/getAllCards.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCardIds": ()=>getCardIds,
    "getCardsOfAllTypes": ()=>getCardsOfAllTypes,
    "getNumOfCards": ()=>getNumOfCards,
    "initPlayCardsAndGetTheirIds": ()=>initPlayCardsAndGetTheirIds,
    "initiateCardsInIdb": ()=>initiateCardsInIdb,
    "prepareCardsForInit": ()=>prepareCardsForInit
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getNormalCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/getNormalCards.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getTypeInCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/getTypeInCards.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getIsCorrectCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/getIsCorrectCards.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/helpers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fisherYatesShafle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/fisherYatesShafle.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/explicitCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/typeInCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/isCorrectCardStoryAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function getCardsOfAllTypes(param) {
    let { nOfTypeInCards, nOfIsCorrectCards, nOfNormalCards, nOfExplicitCards, allShortCards, allExplicitCardStories, optionsHeap } = param;
    const normalCards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getNormalCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNormalCards"])({
        requiredNum: nOfNormalCards,
        shortCards: allShortCards,
        allOptions: optionsHeap
    });
    const typeInCards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getTypeInCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTypeInCards"])({
        requiredNum: nOfTypeInCards,
        shortCards: allShortCards,
        playExplicitCards: allExplicitCardStories
    });
    const isCorrectCards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getIsCorrectCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIsCorrectCards"])({
        requiredNum: nOfIsCorrectCards,
        playExplicitCards: allExplicitCardStories,
        allOptions: optionsHeap,
        shortCards: allShortCards
    });
    const explicitCards = allExplicitCardStories.slice(0, nOfExplicitCards);
    return [
        ...normalCards,
        ...typeInCards,
        ...isCorrectCards,
        ...explicitCards
    ];
}
function prepareCardsForInit(param) {
    let { get, explicitCardIds, shortCardIds } = param;
    const allExplicitCardStories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllExplicitCards"])({
        get,
        explicitCardIds
    });
    const allShortCards = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllShortCards"])({
        get,
        shortCardIds
    });
    const optionsHeap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$helpers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getOptionsHeap"])({
        playExplicitCards: allExplicitCardStories,
        shortCards: allShortCards
    });
    return {
        allExplicitCardStories,
        allShortCards,
        optionsHeap
    };
}
function getNumOfCards(param) {
    let { isSmartMode, optionsHeap, explicitCardIds, shortCardIds, numOfExplicitCards, numOfNormalCards, numOfTypeInCards, numOfIsCorrectCards } = param;
    const smartNumOfNormCards = Math.floor(optionsHeap.length / 4);
    const smartNumOfTypeInCards = Math.floor(explicitCardIds.length / 2) + Math.floor(shortCardIds.length / 2);
    const smartNumOfIsCorrectCards = Math.floor(explicitCardIds.length / 2) + Math.floor(shortCardIds.length / 2);
    const smartNumOfExpCards = explicitCardIds.length;
    return isSmartMode ? {
        nOfExplicitCards: smartNumOfExpCards,
        nOfNormalCards: smartNumOfNormCards,
        nOfTypeInCards: smartNumOfTypeInCards,
        nOfIsCorrectCards: smartNumOfIsCorrectCards
    } : {
        nOfExplicitCards: numOfExplicitCards,
        nOfNormalCards: numOfNormalCards,
        nOfTypeInCards: numOfTypeInCards,
        nOfIsCorrectCards: numOfIsCorrectCards
    };
}
function getCardIds(resultArray) {
    const allCardIds = [];
    const playExplicitCardIds = [];
    const typeInCardIds = [];
    const isCorrectCardIds = [];
    for (const { id, type } of resultArray){
        allCardIds.push(id);
        if (type === 'story-explicitCard') {
            playExplicitCardIds.push(id);
        } else if (type === 'story-isCorrectCard') {
            isCorrectCardIds.push(id);
        } else if (type === 'story-typeInCard') {
            typeInCardIds.push(id);
        }
    }
    return {
        cardIdsOrder: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$fisherYatesShafle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(allCardIds),
        playExplicitCardIds,
        typeInCardIds,
        isCorrectCardIds
    };
}
function initiateCardsInIdb(param) {
    let { set, resultArray } = param;
    resultArray.forEach((card)=>{
        if (card.type === 'story-explicitCard') {
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardStoryAtom"], card);
        } else if (card.type === 'story-typeInCard') {
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateTypeInCardStoryAtom"], card);
        } else if (card.type === 'story-isCorrectCard') {
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateIsCorrectCardStoryAtom"], card);
        }
    });
}
function initPlayCardsAndGetTheirIds(param) {
    let { isSmartMode, numOfExplicitCards, numOfNormalCards, numOfTypeInCards, numOfIsCorrectCards, get, bookId, set } = param;
    const { explicitCardIds, shortCardIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const { allExplicitCardStories, allShortCards, optionsHeap } = prepareCardsForInit({
        get,
        explicitCardIds,
        shortCardIds
    });
    const resultArray = getCardsOfAllTypes({
        ...getNumOfCards({
            optionsHeap,
            shortCardIds,
            explicitCardIds,
            isSmartMode,
            numOfExplicitCards,
            numOfNormalCards,
            numOfTypeInCards,
            numOfIsCorrectCards
        }),
        optionsHeap,
        allExplicitCardStories,
        allShortCards
    });
    initiateCardsInIdb({
        set,
        resultArray
    }); // potentially dangerous - unhandled async code. But it has to be tried
    return getCardIds(resultArray);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/historyAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "EXPLICIT_CARD_STEP": ()=>EXPLICIT_CARD_STEP,
    "IS_CORRECT_CARD_STEP": ()=>IS_CORRECT_CARD_STEP,
    "TYPE_IN_CARD_STEP": ()=>TYPE_IN_CARD_STEP,
    "addNewStoryAtom": ()=>addNewStoryAtom,
    "countCorrectChoicesAtom": ()=>countCorrectChoicesAtom,
    "deleteStoryAtom": ()=>deleteStoryAtom,
    "finishStoryAtom": ()=>finishStoryAtom,
    "getExpStoryCardCorrectOptionIndexAtom": ()=>getExpStoryCardCorrectOptionIndexAtom,
    "getIfExpStoryCardCorrectAtom": ()=>getIfExpStoryCardCorrectAtom,
    "getIfTypeInCardCorrectAtom": ()=>getIfTypeInCardCorrectAtom,
    "getIsCorrectCardCorrectAtom": ()=>getIsCorrectCardCorrectAtom,
    "getNumOfChoicesCalculator": ()=>getNumOfChoicesCalculator,
    "getOverAllCountAtom": ()=>getOverAllCountAtom,
    "getOverAllCountOfCorrectAnswersAtom": ()=>getOverAllCountOfCorrectAnswersAtom,
    "getStoryCompletionDataAtom": ()=>getStoryCompletionDataAtom,
    "getStoryResultsAtom": ()=>getStoryResultsAtom,
    "newStorySettingsAtom": ()=>newStorySettingsAtom,
    "storiesSortedByBookAtom": ()=>storiesSortedByBookAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getAllCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createNewStory/getAllCards.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getUniqueID.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$emptyObjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/emptyObjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/getDerivedAtomWithIdb.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/explicitCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/typeInCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/isCorrectCardStoryAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const deleteStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, storyId)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteStoryIdb"])(mainDb, storyId);
    const { explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
    await Promise.all([
        ...explicitCardStoryIds.map((id)=>set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExplicitCardStoryAtom"], id)),
        ...typeInCardStoryIds.map((id)=>set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteTypeInCardStoryAtom"], id)),
        isCorrectCardStoryIds.map((id)=>set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteIsCorrectCardStoryAtom"], id))
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"].remove(storyId);
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteIdAtom"], {
        idManager: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storyIdsAtom"],
        deleteId: storyId
    });
});
const finishStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, storyId)=>{
    const prevStory = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
    const newStory = {
        ...prevStory,
        isCompleted: true
    };
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateStoryIdb"])(mainDb, newStory);
    set((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId), newStory);
});
const storiesSortedByBookAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
    const bookAndStoriesAssociations = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAndStoriesAssociationsAtom"]);
    const bookIds = Object.keys(bookAndStoriesAssociations);
    return bookIds.map((bookId)=>{
        const { bookTitle } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
        return {
            bookTitle,
            storyIds: bookAndStoriesAssociations[bookId]
        };
    });
});
const newStorySettingsAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$emptyObjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_STORY_SETTINGS_ATOM"]);
const addNewStoryAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$getDerivedAtomWithIdb$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDerivedAtomWithIdb"])(async (get, set, mainDb, param)=>{
    let { settings, bookId, successCallback } = param;
    const { bookTitle, description } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const { cardIdsOrder, playExplicitCardIds, typeInCardIds, isCorrectCardIds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createNewStory$2f$getAllCards$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initPlayCardsAndGetTheirIds"])({
        ...settings,
        bookId,
        get,
        set
    });
    const newStoryId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getUniqueID$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const newStory = {
        id: newStoryId,
        showAnswersImmediately: false,
        isCompleted: false,
        timeSpentSec: 0,
        playStartDate: 0,
        bookId,
        cardIdsOrder,
        explicitCardStoryIds: playExplicitCardIds,
        typeInCardStoryIds: typeInCardIds,
        isCorrectCardStoryIds: isCorrectCardIds,
        bookData: {
            title: bookTitle,
            description
        }
    };
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateStoryIdb"])(mainDb, newStory);
    successCallback(newStoryId);
});
function getNumOfChoicesCalculator(/* 'todo' - move this function somewhere else, where it should be  */ targetAtomFamily) {
    return (ids)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
            let count = 0;
            ids.forEach((id)=>{
                const { currentValue } = get(targetAtomFamily(id));
                if (typeof currentValue === 'string' && currentValue.length === 0) return;
                if (currentValue !== null) count++;
            });
            return count;
        });
}
const getCalcNumOfChoicesInExpCardStoriesAtom = getNumOfChoicesCalculator(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"]);
const getCalcNumOfChoicesInTypeInCardStoriesAtom = getNumOfChoicesCalculator(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"]);
const getCalcNumOfChoicesInIsCorrectCardStoriesAtom = getNumOfChoicesCalculator(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"]);
const getCalcNumOfChoicesAtom = (param)=>{
    let { explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const expCardChoicesCount = get(getCalcNumOfChoicesInExpCardStoriesAtom(explicitCardStoryIds));
        const typeInCardChoicesCount = get(getCalcNumOfChoicesInTypeInCardStoriesAtom(typeInCardStoryIds));
        const isCorrectCardChoicesCount = get(getCalcNumOfChoicesInIsCorrectCardStoriesAtom(isCorrectCardStoryIds));
        return expCardChoicesCount + typeInCardChoicesCount + isCorrectCardChoicesCount;
    });
};
const getStoryCompletionDataAtom = (storyId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { cardIdsOrder, explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
        const numOfCards = cardIdsOrder.length;
        const numOfChoices = get(getCalcNumOfChoicesAtom({
            explicitCardStoryIds,
            typeInCardStoryIds,
            isCorrectCardStoryIds
        }));
        const completionPercentage = Math.round(numOfChoices / numOfCards * 100);
        return {
            completionPercentage,
            numOfChoices,
            numOfCards
        };
    });
const getExpStoryCardCorrectOptionIndexAtom = (cardId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        /* 'todo' - need to make it suitable for multichoice cards */ const { options } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"])(cardId));
        return options.findIndex((opt)=>opt.isCorrect);
    });
const getIfExpStoryCardCorrectAtom = (cardId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { currentValue } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"])(cardId));
        const correctIndex = get(getExpStoryCardCorrectOptionIndexAtom(cardId));
        return currentValue === correctIndex;
    });
const getIfTypeInCardCorrectAtom = (cardId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { currentValue, expectedInput } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"])(cardId));
        return currentValue.toLowerCase().trim() === expectedInput.toLowerCase().trim();
    });
const getIsCorrectCardCorrectAtom = (cardId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { currentValue, isCorrect } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"])(cardId));
        return currentValue === isCorrect;
    });
const countCorrectChoicesAtom = (param)=>{
    let { cardIds, counter, step } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        let count = 0;
        for (const cardId of cardIds){
            const isCorrect = get(counter(cardId));
            if (isCorrect) count += step;
        }
        return count;
    });
};
const EXPLICIT_CARD_STEP = 1;
const TYPE_IN_CARD_STEP = 2;
const IS_CORRECT_CARD_STEP = 0.5;
const getOverAllCountOfCorrectAnswersAtom = (storyId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
        const countOfAllCorrChoicesExpCardStories = get(countCorrectChoicesAtom({
            cardIds: explicitCardStoryIds,
            counter: getIfExpStoryCardCorrectAtom,
            step: 1
        }));
        const countOfAllCorrChoicesTypeInCardStories = get(countCorrectChoicesAtom({
            cardIds: typeInCardStoryIds,
            counter: getIfTypeInCardCorrectAtom,
            step: 1
        }));
        const countOfAllCorrChoicesIsCorrectCardStories = get(countCorrectChoicesAtom({
            cardIds: isCorrectCardStoryIds,
            counter: getIsCorrectCardCorrectAtom,
            step: 1
        }));
        return countOfAllCorrChoicesExpCardStories + countOfAllCorrChoicesTypeInCardStories + countOfAllCorrChoicesIsCorrectCardStories;
    });
const countCardsPointsAtom = (param)=>{
    let { numOfCards, multiplier } = param;
    return numOfCards * multiplier;
};
const getOverAllCountAtom = (storyId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const { explicitCardStoryIds, typeInCardStoryIds, isCorrectCardStoryIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
        const expCardStoriesPointsCount = countCardsPointsAtom({
            numOfCards: explicitCardStoryIds.length,
            multiplier: EXPLICIT_CARD_STEP
        });
        const typeInCardStoriesPointsCount = countCardsPointsAtom({
            numOfCards: typeInCardStoryIds.length,
            multiplier: TYPE_IN_CARD_STEP
        });
        const isCorrectCardStoriesPointsCount = countCardsPointsAtom({
            numOfCards: isCorrectCardStoryIds.length,
            multiplier: IS_CORRECT_CARD_STEP
        });
        return expCardStoriesPointsCount + typeInCardStoriesPointsCount + isCorrectCardStoriesPointsCount;
    });
const getStoryResultsAtom = (storyId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>{
        const countGainedPoints = get(getOverAllCountOfCorrectAnswersAtom(storyId));
        const countAllPoints = get(getOverAllCountAtom(storyId));
        const successPercentage = Math.floor(countGainedPoints / countAllPoints * 100);
        const markIn12PointsSystem = Math.round(successPercentage * 12 / 100);
        return {
            countAllPoints,
            countGainedPoints,
            successPercentage,
            markIn12PointsSystem
        };
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/newStoryParamsModal.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "closeNewStorySettingsDialogAtom": ()=>closeNewStorySettingsDialogAtom,
    "newStoryTemporaryInfoAtom": ()=>newStoryTemporaryInfoAtom,
    "openNewStorySettingsDialogAtom": ()=>openNewStorySettingsDialogAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$emptyObjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/emptyObjects.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/historyAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
const newStoryTemporaryInfoAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$emptyObjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_NEW_STORY_TEMPORARY_INFO"]);
function getNumOfAllExplicitCardOptionsInBook(param) {
    let { get, explicitCardIds } = param;
    let numOfOptions = 0;
    for (const cardId of explicitCardIds){
        const { childrenIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"])(cardId));
        numOfOptions += childrenIds.length;
    }
    return numOfOptions;
}
const openNewStorySettingsDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, bookId)=>{
    set(setNewStorySettingsAtomToDefaultAtom, bookId);
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openDialogAtom"], 'newStoryParams');
});
const closeNewStorySettingsDialogAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set)=>{
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$emptyObjects$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_STORY_SETTINGS_ATOM"]);
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideDialogAtom"], 'newStoryParams');
});
const setNewStorySettingsAtomToDefaultAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, bookId)=>{
    const { shortCardIds, explicitCardIds } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const numOfExplicitCardOptions = getNumOfAllExplicitCardOptionsInBook({
        get,
        explicitCardIds
    });
    const maxNumOfNormalCards = Math.floor((numOfExplicitCardOptions + shortCardIds.length) / 4);
    const numOfTypeInCards = Math.floor((shortCardIds.length - maxNumOfNormalCards) / 2);
    const numOfIsCorrectCards = Math.floor((shortCardIds.length - maxNumOfNormalCards) / 2);
    const numOfAllCards = explicitCardIds.length + shortCardIds.length;
    set(newStoryTemporaryInfoAtom, {
        maxNumOfExplicitCards: explicitCardIds.length,
        maxNumOfNormalCards,
        maxNumOfTypeInCards: numOfAllCards,
        maxNumOfIsCorrectCards: numOfAllCards
    });
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"], {
        isSmartMode: true,
        showAnswersImmediately: false,
        numOfExplicitCards: explicitCardIds.length,
        numOfNormalCards: maxNumOfNormalCards,
        numOfTypeInCards,
        numOfIsCorrectCards,
        bookId
    });
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/jotai/storiesForBookDialogInfoAtoms.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "closeAndClearBookStoryDialog": ()=>closeAndClearBookStoryDialog,
    "openBookStoryDialog": ()=>openBookStoryDialog,
    "storiesForBookDialogInfoAtom": ()=>storiesForBookDialogInfoAtom,
    "updateBookStoriesDataAtom": ()=>updateBookStoriesDataAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/newStoryParamsModal.ts [app-client] (ecmascript)");
;
;
;
;
;
const EMPTY_STORIES_FOR_BOOK = {
    bookTitle: '',
    storyIds: [],
    createOnAddNewStoryClick: ()=>()=>{}
};
const storiesForBookDialogInfoAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(EMPTY_STORIES_FOR_BOOK);
const closeAndClearBookStoryDialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (_get, set)=>{
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideDialogAtom"], 'storiesForBook');
    set(storiesForBookDialogInfoAtom, EMPTY_STORIES_FOR_BOOK);
});
const updateBookStoriesDataAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, bookId)=>{
    const newAssociations = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAndStoriesAssociationsAtom"]);
    const storyIds = newAssociations[bookId];
    if (typeof storyIds === 'undefined') {
        set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideDialogAtom"], 'storiesForBook');
    } else {
        set(storiesForBookDialogInfoAtom, (prev)=>({
                ...prev,
                storyIds
            }));
    }
});
const openBookStoryDialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])(null, (get, set, bookId)=>{
    const { bookTitle } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
    const storyIds = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAssociationsForBookAtomOnlyIncomplete"])(bookId));
    const createOnAddNewStoryClick = ()=>()=>{
            set(closeAndClearBookStoryDialog);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openNewStorySettingsDialogAtom"], bookId);
        };
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdForStoriesDialogAtom"], bookId);
    set(storiesForBookDialogInfoAtom, {
        bookTitle,
        storyIds,
        createOnAddNewStoryClick
    });
    set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openDialogAtom"], 'storiesForBook');
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/historyRelated/onStudyBtnClick.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>useStudyButtonClickHandler
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$snackbarAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/snackbarAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/storiesForBookDialogInfoAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/newStoryParamsModal.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function useStudyButtonClickHandler(bookId) {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"])({
        "useStudyButtonClickHandler.useAtomCallback": (get, set)=>{
            const { cardIdsOrder } = get((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(bookId));
            const booksAndStoriesAssociations = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAndStoriesAssociationsAtom"]);
            if (cardIdsOrder.length === 0) {
                set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$snackbarAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showSnackbarAtom"], {
                    snackbarName: 'noCardsErrorSnackbar',
                    timeMS: 5_000
                });
            } else if (bookId in booksAndStoriesAssociations) {
                set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openBookStoryDialog"], bookId);
            } else {
                set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["openNewStorySettingsDialogAtom"], bookId);
            }
        }
    }["useStudyButtonClickHandler.useAtomCallback"]);
}
_s(useStudyButtonClickHandler, "71OAR3ssNnefB00Hq+zkC0b2NcU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/StudyButton/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>StudyButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$historyRelated$2f$onStudyBtnClick$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/historyRelated/onStudyBtnClick.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function StudyButton() {
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"])();
    const onClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$historyRelated$2f$onStudyBtnClick$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(id);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookCard.playBookBtn,
        className: "mt-5 w-full text-white  hover:bg-blue-200 p-2 rounded-md bg-blue-400 duration-100",
        onClick: onClick,
        children: "study"
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/StudyButton/index.tsx",
        lineNumber: 11,
        columnNumber: 17
    }, this);
}
_s(StudyButton, "ql7cmwweGtByH8l6XN3/e0huN7w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBookProps"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$historyRelated$2f$onStudyBtnClick$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = StudyButton;
var _c;
__turbopack_context__.k.register(_c, "StudyButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/createPropsProvider.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createPropsProvider": ()=>createPropsProvider
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
function createPropsProvider(displayName) {
    var _s = __turbopack_context__.k.signature();
    const Context = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
    const Provider = (props)=>{
        const { children, ...rest } = props; // "rest" — це наш P
        const value = rest;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Context.Provider, {
            value: value,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/utils/createPropsProvider.tsx",
            lineNumber: 16,
            columnNumber: 25
        }, this);
    };
    Provider.displayName = displayName !== null && displayName !== void 0 ? displayName : 'PropsProvider';
    function usePropsContext() {
        _s();
        const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Context);
        if (!ctx) {
            throw new Error("".concat(Provider.displayName, " must be used within its Provider"));
        }
        return ctx;
    }
    _s(usePropsContext, "/dMy7t63NXD4eYACoT93CePwGrg=");
    return {
        Provider,
        usePropsContext,
        Context
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BookPropsProvider": ()=>BookPropsProvider,
    "default": ()=>BookItem,
    "useBookProps": ()=>useBookProps
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookTitle$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/BookTitle/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$Description$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/Description/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$OtherInfo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/OtherInfo/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/BookToolbar/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$StudyButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/StudyButton/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createPropsProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/createPropsProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const { Provider: BookPropsProvider, usePropsContext: useBookProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$createPropsProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPropsProvider"])('BookItemProps');
function BookItem(param) {
    let { id } = param;
    _s();
    const { bookTitle, lastChangeDate, cardIdsOrder, description } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"])(id));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookPropsProvider, {
        bookTitle,
        lastChangeDate,
        cardsLength: cardIdsOrder.length,
        description,
        id,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookCard.me,
            className: "w-full flex flex-col h-fit rounded-normal overflow-hidden border p-6 border-lightGray",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookToolbar$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
                    lineNumber: 38,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$BookTitle$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
                    lineNumber: 39,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$Description$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
                    lineNumber: 40,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$OtherInfo$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
                    lineNumber: 41,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$StudyButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
                    lineNumber: 43,
                    columnNumber: 33
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
            lineNumber: 37,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/RenderBooks/Book/index.tsx",
        lineNumber: 29,
        columnNumber: 17
    }, this);
}
_s(BookItem, "+KAA1gMJCSITZJH/m2VHiezexBQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = BookItem;
var _c;
__turbopack_context__.k.register(_c, "BookItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/NothingYet/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>NothingYetMessage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
function NothingYetMessage(param) {
    let { message, listLength, className } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('hidden', {
            'text-6xl max-md:text-5xl max-[424px]:text-4xl w-full col-span-full font-bold mx-auto mt-18 !flex text-gray-300': listLength === 0
        }, className),
        children: message
    }, void 0, false, {
        fileName: "[project]/src/components/general/NothingYet/index.tsx",
        lineNumber: 13,
        columnNumber: 17
    }, this);
}
_c = NothingYetMessage;
var _c;
__turbopack_context__.k.register(_c, "NothingYetMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/RenderBooks/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>RenderBooks
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/Book/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$NothingYet$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/NothingYet/index.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function RenderBooks() {
    _s();
    const booksIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksIdsAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-3 w-full h-fit gap-4 max-lg:grid-cols-2 max-sm:grid-cols-1",
        children: [
            booksIds.map((id)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                    fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: "loading..."
                    }, void 0, false, {
                        fileName: "[project]/src/components/books_page/RenderBooks/index.tsx",
                        lineNumber: 17,
                        columnNumber: 51
                    }, void 0),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$Book$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        id: id
                    }, void 0, false, {
                        fileName: "[project]/src/components/books_page/RenderBooks/index.tsx",
                        lineNumber: 18,
                        columnNumber: 41
                    }, this)
                }, id, false, {
                    fileName: "[project]/src/components/books_page/RenderBooks/index.tsx",
                    lineNumber: 15,
                    columnNumber: 33
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$NothingYet$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                message: "No books yet",
                listLength: booksIds.length
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/RenderBooks/index.tsx",
                lineNumber: 21,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/RenderBooks/index.tsx",
        lineNumber: 13,
        columnNumber: 17
    }, this);
}
_s(RenderBooks, "Q3FWr36dXW6/c2tHNGWgLdE/kQI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = RenderBooks;
var _c;
__turbopack_context__.k.register(_c, "RenderBooks");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/AddBookButton/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>AddBookButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/io5/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/bookAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function AddBookButton() {
    _s();
    const add = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEmptyBookAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].addNewBookBtn,
        onClick: add,
        className: "fixed bottom-[25px] right-5",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoAddCircle"], {
            className: "text-6xl hover:rotate-45 duration-200 bg-white rounded-full shadow-xl"
        }, void 0, false, {
            fileName: "[project]/src/components/books_page/AddBookButton/index.tsx",
            lineNumber: 14,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/AddBookButton/index.tsx",
        lineNumber: 10,
        columnNumber: 17
    }, this);
}
_s(AddBookButton, "zlMgBQ+X0M9+d7dhiiQhRimh9+8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"]
    ];
});
_c = AddBookButton;
var _c;
__turbopack_context__.k.register(_c, "AddBookButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/jotaiRelated/initializers.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useInitAtomFamily": ()=>useInitAtomFamily
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
function useInitAtomFamily(familyAtom) {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useInitAtomFamily.useAtomCallback.useCallback": (_get, set, array)=>{
            array.forEach({
                "useInitAtomFamily.useAtomCallback.useCallback": (item)=>set(familyAtom(item.id), item)
            }["useInitAtomFamily.useAtomCallback.useCallback"]);
        }
    }["useInitAtomFamily.useAtomCallback.useCallback"], []));
}
_s(useInitAtomFamily, "71OAR3ssNnefB00Hq+zkC0b2NcU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "InitAllMainDbAtoms_DO_NOT_IMPORT": ()=>InitAllMainDbAtoms_DO_NOT_IMPORT,
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/main/actions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/jotaiRelated/initializers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$idUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/idb/idUtils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
async function initEntity(param) {
    let { promise, setAll, setIds, initFamily } = param;
    return promise.then((items)=>{
        if (setAll) setAll(items);
        if (setIds) setIds((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$idUtils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pickIds"])(items));
        initFamily(items);
    });
}
async function useGetInitBooks(asyncMainDb) {
    _s();
    const setBooksIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksIdsAtom"]);
    const initBooksAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllBooksFromAsyncDb"])(asyncMainDb),
        setIds: setBooksIds,
        initFamily: initBooksAtomFamily
    });
}
_s(useGetInitBooks, "LJ+wDy1n6mSq+E77y4hlAJPEMtY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitExplicitCards(asyncMainDb) {
    _s1();
    const initExplicitCardsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllExplicitCardsFromAsyncDb"])(asyncMainDb),
        initFamily: initExplicitCardsAtomFamily
    });
}
_s1(useGetInitExplicitCards, "PrfIZS7duc4mNRugCD6dKNMe3dQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitOptions(asyncMainDb) {
    _s2();
    const initOptionsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllOptionsFromAsyncDb"])(asyncMainDb),
        initFamily: initOptionsAtomFamily
    });
}
_s2(useGetInitOptions, "0g+FtHYtYtDni2seCsBT2dnpeO0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitShortCards(asyncMainDb) {
    _s3();
    const initShortCardsAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllShortCardsFromAsyncDb"])(asyncMainDb),
        initFamily: initShortCardsAtomFamily
    });
}
_s3(useGetInitShortCards, "8m/jtadlfwcR+mK2p91uCfFCIZw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitStories(asyncMainDb) {
    _s4();
    const setStoryIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storyIdsAtom"]);
    const initStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllStoriesFromAsyncDb"])(asyncMainDb),
        setIds: setStoryIds,
        initFamily: initStoriesAtomFamily
    });
}
_s4(useGetInitStories, "fwblWL8usVLgkYP4jquNZoL4kgw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitExplicitCardStories(asyncMainDb) {
    _s5();
    const initExpCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllExplicitCardStoriesFromAsyncDb"])(asyncMainDb),
        initFamily: initExpCardStoriesAtomFamily
    });
}
_s5(useGetInitExplicitCardStories, "ylM4N0lcgCxWSgD43HY6IdMZLyI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitTypeInCardStories(asyncMainDb) {
    _s6();
    const initTypeInCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllTypeInCardStoriesFromAsyncDb"])(asyncMainDb),
        initFamily: initTypeInCardStoriesAtomFamily
    });
}
_s6(useGetInitTypeInCardStories, "1PwHBGbOxyevvxNAPf9EJiDcfYo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
async function useGetInitIsCorrectCardStories(asyncMainDb) {
    _s7();
    const initIsCorrectCardStoriesAtomFamily = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"]);
    return initEntity({
        promise: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllIsCorrectCardStoriesFromAsyncDb"])(asyncMainDb),
        initFamily: initIsCorrectCardStoriesAtomFamily
    });
}
_s7(useGetInitIsCorrectCardStories, "HjYj4MxnBdVl6P5aktGnuZNc7Lw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$jotaiRelated$2f$initializers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitAtomFamily"]
    ];
});
const InitAllMainDbAtoms_DO_NOT_IMPORT = /*#__PURE__*/ _s8((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(_c = _s8(function InitAllMainDbAtoms_DO_NOT_IMPORT() {
    _s8();
    const asyncMainDb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$idb$2f$main$2f$actions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMainDb"])();
    const setMainDb = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mainDbAtom"]);
    const setIsInitCompleted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInitializationFromIdbCompletedAtom"]);
    const p1 = useGetInitBooks(asyncMainDb);
    const p2 = useGetInitExplicitCards(asyncMainDb);
    const p3 = useGetInitOptions(asyncMainDb);
    const p4 = useGetInitShortCards(asyncMainDb);
    const p5 = useGetInitStories(asyncMainDb);
    const p6 = useGetInitExplicitCardStories(asyncMainDb);
    const p7 = useGetInitTypeInCardStories(asyncMainDb);
    const p8 = useGetInitIsCorrectCardStories(asyncMainDb);
    const mainDbPromise = asyncMainDb.then((db)=>{
        setMainDb(db);
    });
    Promise.all([
        p1,
        p2,
        p3,
        p4,
        p5,
        p6,
        p7,
        p8,
        mainDbPromise
    ]).then(()=>{
        setIsInitCompleted(true);
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}, void 0, false);
}, "nIOm5/COlAy6Vx+xkaJSqZurEUY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        useGetInitBooks,
        useGetInitExplicitCards,
        useGetInitOptions,
        useGetInitShortCards,
        useGetInitStories,
        useGetInitExplicitCardStories,
        useGetInitTypeInCardStories,
        useGetInitIsCorrectCardStories
    ];
})), "nIOm5/COlAy6Vx+xkaJSqZurEUY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetAtom"],
        useGetInitBooks,
        useGetInitExplicitCards,
        useGetInitOptions,
        useGetInitShortCards,
        useGetInitStories,
        useGetInitExplicitCardStories,
        useGetInitTypeInCardStories,
        useGetInitIsCorrectCardStories
    ];
});
_c1 = InitAllMainDbAtoms_DO_NOT_IMPORT;
const __TURBOPACK__default__export__ = _c3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_c2 = ()=>__turbopack_context__.r("[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i).then((modules)=>modules.InitAllMainDbAtoms_DO_NOT_IMPORT), {
    loadableGenerated: {
        modules: [
            "[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "InitAllMainDbAtoms_DO_NOT_IMPORT$memo");
__turbopack_context__.k.register(_c1, "InitAllMainDbAtoms_DO_NOT_IMPORT");
__turbopack_context__.k.register(_c2, "%default%$dynamic");
__turbopack_context__.k.register(_c3, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/Snackbar/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>Snackbar
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/io5/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Snackbar(param) {
    let { snackbarName, message } = param;
    _s();
    const isVisible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dialogVisibilityFamilyAtom"])(snackbarName));
    const state = isVisible ? 'visible' : 'hidden';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-state": state,
        className: "fixed bottom-10 left-10 !flex p-4 gap-3 rounded-md bg-yellow-500 opacity-0 items-center -z-50 data-[state=visible]:z-10 data-[state=visible]:opacity-100 duration-200",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "heading-4 !text-white",
                children: message
            }, void 0, false, {
                fileName: "[project]/src/components/general/Snackbar/index.tsx",
                lineNumber: 24,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoWarning"], {
                className: "text-yellow-900 text-2xl"
            }, void 0, false, {
                fileName: "[project]/src/components/general/Snackbar/index.tsx",
                lineNumber: 25,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/general/Snackbar/index.tsx",
        lineNumber: 21,
        columnNumber: 17
    }, this);
}
_s(Snackbar, "0O2yD6lJLFf3BYYvnldeAz0Ea+M=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = Snackbar;
var _c;
__turbopack_context__.k.register(_c, "Snackbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/useCloseModalWhenClickOutOfContainer.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>useCloseModalWhenClickOutOfContainer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useCloseModalWhenClickOutOfContainer(containerRef, callback) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useCloseModalWhenClickOutOfContainer.useEffect": ()=>{
            var _containerRef_current;
            if (!containerRef.current) throw 'Container ref for modal (edit cards as text) is not of truthy value. Cannot add click listener to it';
            const clickListener = {
                "useCloseModalWhenClickOutOfContainer.useEffect.clickListener": (e)=>{
                    if (e.target === containerRef.current) {
                        callback();
                    }
                }
            }["useCloseModalWhenClickOutOfContainer.useEffect.clickListener"];
            (_containerRef_current = containerRef.current) === null || _containerRef_current === void 0 ? void 0 : _containerRef_current.addEventListener('click', clickListener);
            return ({
                "useCloseModalWhenClickOutOfContainer.useEffect": ()=>{
                    var _containerRef_current;
                    (_containerRef_current = containerRef.current) === null || _containerRef_current === void 0 ? void 0 : _containerRef_current.removeEventListener('click', clickListener);
                }
            })["useCloseModalWhenClickOutOfContainer.useEffect"];
        }
    }["useCloseModalWhenClickOutOfContainer.useEffect"], []);
}
_s(useCloseModalWhenClickOutOfContainer, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/Dialog/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 'todo' - refactor this component
__turbopack_context__.s({
    "default": ()=>Dialog
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCloseModalWhenClickOutOfContainer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useCloseModalWhenClickOutOfContainer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/io5/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
function Dialog(param) {
    let { children, dialogName, className, containerClassName, onCloseSideEffectAction, testId, CloseDialogComponent } = param;
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [dialogVisible, setDialogVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dialogVisibilityFamilyAtom"])(dialogName));
    const dialogState = dialogVisible ? 'open' : 'closed';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCloseModalWhenClickOutOfContainer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(containerRef, {
        "Dialog.useCloseModalWhenClickOutOfContainer": ()=>{
            setDialogVisible(false);
            if (typeof onCloseSideEffectAction === 'function') {
                onCloseSideEffectAction();
            }
        }
    }["Dialog.useCloseModalWhenClickOutOfContainer"]);
    const onCloseDialogButtonClick = ()=>{
        setDialogVisible(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-testid": testId,
        role: "dialog",
        ref: containerRef,
        "data-state": dialogState,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50 w-screen h-screen data-[state=closed]:hidden', containerClassName),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            tabIndex: -1,
            "data-state": dialogState,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('fixed top-[50%] left-[50%] z-50 flex flex-col translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border shadow-lg duration-200 w-8/12 max-sm:!w-full max-sm:h-full', className),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onCloseDialogButtonClick,
                    type: "button",
                    className: "ml-auto text-2xl text-black",
                    children: typeof CloseDialogComponent === 'function' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CloseDialogComponent, {}, void 0, false, {
                        fileName: "[project]/src/components/general/Dialog/index.tsx",
                        lineNumber: 70,
                        columnNumber: 49
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoClose"], {
                        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BASE_DIALOG_TEST_IDS"].defCloseBtn
                    }, void 0, false, {
                        fileName: "[project]/src/components/general/Dialog/index.tsx",
                        lineNumber: 72,
                        columnNumber: 49
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/general/Dialog/index.tsx",
                    lineNumber: 64,
                    columnNumber: 33
                }, this),
                children
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/general/Dialog/index.tsx",
            lineNumber: 57,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/general/Dialog/index.tsx",
        lineNumber: 48,
        columnNumber: 17
    }, this);
}
_s(Dialog, "mzQeybTUod2FRzlDDubAf5gtKYQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useCloseModalWhenClickOutOfContainer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = Dialog;
var _c;
__turbopack_context__.k.register(_c, "Dialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/getDefPathToPlayPage.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>getDefaultPathToPlayPage
});
function getDefaultPathToPlayPage(storyId) {
    return "play?storyId=".concat(storyId);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/StoryItem/client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CompletionRate": ()=>CompletionRate,
    "CompletionRateLikeBread": ()=>CompletionRateLikeBread,
    "DeleteStoryButton": ()=>DeleteStoryButton,
    "StoryCreationDate": ()=>StoryCreationDate
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Bread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Bread/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/md/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/historyAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/storiesForBookDialogInfoAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/idManagers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$DateBread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/DateBread/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function CompletionRateLikeBread(param) {
    let { storyId } = param;
    _s();
    const stableAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CompletionRateLikeBread.useMemo[stableAtom]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStoryCompletionDataAtom"])(storyId)
    }["CompletionRateLikeBread.useMemo[stableAtom]"], []);
    const { numOfChoices, numOfCards } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(stableAtom);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Bread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        items: [
            numOfChoices,
            numOfCards
        ],
        className: "mr-auto"
    }, void 0, false, {
        fileName: "[project]/src/components/general/StoryItem/client.tsx",
        lineNumber: 24,
        columnNumber: 16
    }, this);
}
_s(CompletionRateLikeBread, "SGAXx4PANSxrKLZQaQLQRlJDdOA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = CompletionRateLikeBread;
function DeleteStoryButton(param) {
    let { storyId } = param;
    _s1();
    const onDeleteButtonClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"])({
        "DeleteStoryButton.useAtomCallback[onDeleteButtonClick]": async (get, set, e)=>{
            e.stopPropagation();
            const bookId = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$idManagers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentBookIdForStoriesDialogAtom"]);
            await set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteStoryAtom"], storyId);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookStoriesDataAtom"], bookId);
        }
    }["DeleteStoryButton.useAtomCallback[onDeleteButtonClick]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "absolute top-0 right-0 bg-red-200 hover:bg-red-500 duration-100 rounded-bl-2xl rounded-tr-md group",
        onClick: onDeleteButtonClick,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdDeleteOutline"], {
            className: "text-red-400 group-hover:text-white  text-2xl m-2"
        }, void 0, false, {
            fileName: "[project]/src/components/general/StoryItem/client.tsx",
            lineNumber: 40,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/general/StoryItem/client.tsx",
        lineNumber: 37,
        columnNumber: 17
    }, this);
}
_s1(DeleteStoryButton, "PRW+fc6mu6bIk1jGIBiMRyQd+vQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"]
    ];
});
_c1 = DeleteStoryButton;
function CompletionRate(param) {
    let { storyId } = param;
    _s2();
    const stableAtom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CompletionRate.useMemo[stableAtom]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStoryCompletionDataAtom"])(storyId)
    }["CompletionRate.useMemo[stableAtom]"], []);
    const { completionPercentage } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(stableAtom);
    const isPercentageGreen = completionPercentage > 49;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
        "data-isgreen": isPercentageGreen,
        className: "mx-auto heading-1 !text-red-400  data-[isgreen=true]:!text-green-400 !my-0",
        children: "".concat(completionPercentage, "%")
    }, void 0, false, {
        fileName: "[project]/src/components/general/StoryItem/client.tsx",
        lineNumber: 54,
        columnNumber: 17
    }, this);
}
_s2(CompletionRate, "fXDL2/Wln8bfy2Us/fULqJZLlX8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c2 = CompletionRate;
function StoryCreationDate(param) {
    let { storyId } = param;
    _s3();
    const { playStartDate } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesAtomFamily"])(storyId));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$DateBread$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        timeMs: playStartDate,
        className: "ml-auto mt-3"
    }, void 0, false, {
        fileName: "[project]/src/components/general/StoryItem/client.tsx",
        lineNumber: 64,
        columnNumber: 16
    }, this);
}
_s3(StoryCreationDate, "3760pEZC37/YPj/fE90hOZKMA3w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c3 = StoryCreationDate;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "CompletionRateLikeBread");
__turbopack_context__.k.register(_c1, "DeleteStoryButton");
__turbopack_context__.k.register(_c2, "CompletionRate");
__turbopack_context__.k.register(_c3, "StoryCreationDate");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/StoryItem/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>StoryItem
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getDefPathToPlayPage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/dialogVisibilityFamily.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/StoryItem/client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function StoryItem(param) {
    let { storyId } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const onClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"])({
        "StoryItem.useAtomCallback[onClick]": (_get, set)=>{
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$dialogVisibilityFamily$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideDialogAtom"], 'storiesForBook');
            router.replace((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(storyId));
        }
    }["StoryItem.useAtomCallback[onClick]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookStoriesDialog.storyCard,
        onClick: onClick,
        className: "flex flex-col p-6 w-full rounded-md glass hover:shadow-xl relative duration-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompletionRateLikeBread"], {
                storyId: storyId
            }, void 0, false, {
                fileName: "[project]/src/components/general/StoryItem/index.tsx",
                lineNumber: 26,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DeleteStoryButton"], {
                storyId: storyId
            }, void 0, false, {
                fileName: "[project]/src/components/general/StoryItem/index.tsx",
                lineNumber: 27,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompletionRate"], {
                storyId: storyId
            }, void 0, false, {
                fileName: "[project]/src/components/general/StoryItem/index.tsx",
                lineNumber: 28,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoryCreationDate"], {
                storyId: storyId
            }, void 0, false, {
                fileName: "[project]/src/components/general/StoryItem/index.tsx",
                lineNumber: 29,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/general/StoryItem/index.tsx",
        lineNumber: 22,
        columnNumber: 17
    }, this);
}
_s(StoryItem, "Dkc2Aao9n1Lj4+mK/y6/8a/p/B0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"]
    ];
});
_c = StoryItem;
var _c;
__turbopack_context__.k.register(_c, "StoryItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/BookStoryDialog/CreateNewStoryButton/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>CreateNewStoryButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/storiesForBookDialogInfoAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getDefPathToPlayPage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/react-icons@5.5.0_react@19.2.0/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function CreateNewStoryButton() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { createOnAddNewStoryClick } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesForBookDialogInfoAtom"]);
    const onClick = createOnAddNewStoryClick((storyId)=>router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(storyId)));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "button",
        onClick: onClick,
        className: "w-full glass hover:shadow-xl duration-100  rounded-md p-6 h-full flex",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$react$2d$icons$40$5$2e$5$2e$0_react$40$19$2e$2$2e$0$2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaPlus"], {
            className: "text-4xl text-white  mx-auto my-auto"
        }, void 0, false, {
            fileName: "[project]/src/components/books_page/BookStoryDialog/CreateNewStoryButton/index.tsx",
            lineNumber: 23,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/BookStoryDialog/CreateNewStoryButton/index.tsx",
        lineNumber: 19,
        columnNumber: 17
    }, this);
}
_s(CreateNewStoryButton, "/YKiNvjd1XAqPH7abUzTleFjxik=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = CreateNewStoryButton;
var _c;
__turbopack_context__.k.register(_c, "CreateNewStoryButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/BookStoryDialog/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>BookStoryDialog
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Dialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Dialog/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/StoryItem/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/storiesForBookDialogInfoAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$BookStoryDialog$2f$CreateNewStoryButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/BookStoryDialog/CreateNewStoryButton/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function BookStoryDialog() {
    _s();
    const { bookTitle, storyIds } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$storiesForBookDialogInfoAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["storiesForBookDialogInfoAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Dialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].bookStoriesDialog.me,
        dialogName: "storiesForBook",
        className: "bg-white p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "heading-2",
                children: "Some options already exist for '".concat(bookTitle, "' book. Choose one you want to resume, or create a new story")
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/BookStoryDialog/index.tsx",
                lineNumber: 20,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "grid grid-cols-3 gap-4",
                children: [
                    storyIds.map((id)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$StoryItem$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            storyId: id
                        }, id, false, {
                            fileName: "[project]/src/components/books_page/BookStoryDialog/index.tsx",
                            lineNumber: 25,
                            columnNumber: 41
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$BookStoryDialog$2f$CreateNewStoryButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/books_page/BookStoryDialog/index.tsx",
                        lineNumber: 27,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/books_page/BookStoryDialog/index.tsx",
                lineNumber: 23,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/BookStoryDialog/index.tsx",
        lineNumber: 16,
        columnNumber: 17
    }, this);
}
_s(BookStoryDialog, "SuMxx503q6u1fmWb59TGe/FL+jU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c = BookStoryDialog;
var _c;
__turbopack_context__.k.register(_c, "BookStoryDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/jotai/atomAdapters.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 'todo' - in future should rewrite all atomFamilies here into derived atoms. Because under the hood all of them use maps. And at some point they will consume a lot of memory.
// 'todo' - It seems like all of the atom adapters have similar structure. So I can rewrite them into 1 multi adapter
__turbopack_context__.s({
    "getBookDescriptionFamilyAdapterAtom": ()=>getBookDescriptionFamilyAdapterAtom,
    "getBookTitleFamilyAdapterAtom": ()=>getBookTitleFamilyAdapterAtom,
    "getCardOptionTitleFamilyAdapterAtom": ()=>getCardOptionTitleFamilyAdapterAtom,
    "getExplicitCardExplanationFamilyAdapterAtom": ()=>getExplicitCardExplanationFamilyAdapterAtom,
    "getExplicitCardStoryCurrValFamilyAdapterAtom": ()=>getExplicitCardStoryCurrValFamilyAdapterAtom,
    "getExplicitCardSubtitleFamilyAdapterAtom": ()=>getExplicitCardSubtitleFamilyAdapterAtom,
    "getExplicitCardTitleFamilyAdapterAtom": ()=>getExplicitCardTitleFamilyAdapterAtom,
    "getIsCorrectCardStoryCurrValFamilyAdapterAtom": ()=>getIsCorrectCardStoryCurrValFamilyAdapterAtom,
    "getNewStoryIsSmartModeParamAdapterAtom": ()=>getNewStoryIsSmartModeParamAdapterAtom,
    "getNewStoryMaxNumOfExplicitCardsAdapterAtom": ()=>getNewStoryMaxNumOfExplicitCardsAdapterAtom,
    "getNewStoryMaxNumOfIsCorrectCardsAdapterAtom": ()=>getNewStoryMaxNumOfIsCorrectCardsAdapterAtom,
    "getNewStoryMaxNumOfNormalCardsAdapterAtom": ()=>getNewStoryMaxNumOfNormalCardsAdapterAtom,
    "getNewStoryMaxNumOfTypeInCardsAdapterAtom": ()=>getNewStoryMaxNumOfTypeInCardsAdapterAtom,
    "getNewStoryNumOfExplicitCardsParamAdapterAtom": ()=>getNewStoryNumOfExplicitCardsParamAdapterAtom,
    "getNewStoryNumOfIsCorrectCardsParamAdapterAtom": ()=>getNewStoryNumOfIsCorrectCardsParamAdapterAtom,
    "getNewStoryNumOfNormalCardsParamAdapterAtom": ()=>getNewStoryNumOfNormalCardsParamAdapterAtom,
    "getNewStoryNumOfTypeInCardsParamAdapterAtom": ()=>getNewStoryNumOfTypeInCardsParamAdapterAtom,
    "getNewStoryShowAnswersImmediatelyParamAdapterAtom": ()=>getNewStoryShowAnswersImmediatelyParamAdapterAtom,
    "getOptionCorrectnessMarkerFamilyAdapterAtom": ()=>getOptionCorrectnessMarkerFamilyAdapterAtom,
    "getShortCardDefinitionFamilyAdapterAtom": ()=>getShortCardDefinitionFamilyAdapterAtom,
    "getShortCardTermFamilyAdapterAtom": ()=>getShortCardTermFamilyAdapterAtom,
    "getTypeInCardStoryAnswerRevealedFamilyAdapterAtom": ()=>getTypeInCardStoryAnswerRevealedFamilyAdapterAtom,
    "getTypeInCardStoryCurrValFamilyAdapterAtom": ()=>getTypeInCardStoryCurrValFamilyAdapterAtom
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/mainAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/bookAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/cardAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/optionAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/newStoryParamsModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/historyAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/explicitCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/typeInCardStoryAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/isCorrectCardStoryAtoms.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function getAtomFamilyAdapter(param) {
    let { targetAtomFamily, targetProperty, targetUpdateAtom } = param;
    return (targetId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(targetAtomFamily(targetId))[targetProperty], (get, set, newVal)=>{
            const prevAtomValue = get(targetAtomFamily(targetId));
            const newAtomValue = {
                ...prevAtomValue,
                [targetProperty]: newVal
            };
            set(targetUpdateAtom, newAtomValue);
        });
}
function getAtomAdapter(param) {
    let { targetAtom, targetProperty } = param;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["atom"])((get)=>get(targetAtom)[targetProperty], (get, set, newVal)=>{
        const prevAtomValue = get(targetAtom);
        const newAtomValue = {
            ...prevAtomValue,
            [targetProperty]: newVal
        };
        set(targetAtom, newAtomValue);
    });
}
const getBookTitleFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"],
    targetProperty: 'bookTitle',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtom"]
});
const getBookDescriptionFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["booksAtomFamily"],
    targetProperty: 'description',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$bookAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateBookAtom"]
});
const getExplicitCardTitleFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"],
    targetProperty: 'cardTitle',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardAtom"]
});
const getExplicitCardSubtitleFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"],
    targetProperty: 'subtitle',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardAtom"]
});
const getExplicitCardExplanationFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardsAtomFamily"],
    targetProperty: 'explanation',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardAtom"]
});
const getCardOptionTitleFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"],
    targetProperty: 'optionTitle',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionAtom"]
});
const getOptionCorrectnessMarkerFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionsAtomFamily"],
    targetProperty: 'isCorrect',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$optionAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateOptionAtom"]
});
const getShortCardTermFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"],
    targetProperty: 'term',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"]
});
const getShortCardDefinitionFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shortCardsAtomFamily"],
    targetProperty: 'definition',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$cardAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateShortCardAtom"]
});
const getExplicitCardStoryCurrValFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["explicitCardStoriesAtomFamily"],
    targetProperty: 'currentValue',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$explicitCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateExplicitCardStoryAtom"]
});
const getTypeInCardStoryCurrValFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"],
    targetProperty: 'currentValue',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateTypeInCardStoryAtom"]
});
const getTypeInCardStoryAnswerRevealedFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["typeInCardStoriesAtomFamily"],
    targetProperty: "answerRevealed",
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$typeInCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateTypeInCardStoryAtom"]
});
const getIsCorrectCardStoryCurrValFamilyAdapterAtom = getAtomFamilyAdapter({
    targetAtomFamily: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$mainAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCorrectCardStoriesAtomFamily"],
    targetProperty: 'currentValue',
    targetUpdateAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$isCorrectCardStoryAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateIsCorrectCardStoryAtom"]
});
const getNewStoryIsSmartModeParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'isSmartMode'
});
const getNewStoryShowAnswersImmediatelyParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'showAnswersImmediately'
});
const getNewStoryNumOfNormalCardsParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'numOfNormalCards'
});
const getNewStoryNumOfExplicitCardsParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'numOfExplicitCards'
});
const getNewStoryNumOfTypeInCardsParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'numOfTypeInCards'
});
const getNewStoryNumOfIsCorrectCardsParamAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"],
    targetProperty: 'numOfIsCorrectCards'
});
const getNewStoryMaxNumOfExplicitCardsAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStoryTemporaryInfoAtom"],
    targetProperty: 'maxNumOfExplicitCards'
});
const getNewStoryMaxNumOfNormalCardsAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStoryTemporaryInfoAtom"],
    targetProperty: 'maxNumOfNormalCards'
});
const getNewStoryMaxNumOfTypeInCardsAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStoryTemporaryInfoAtom"],
    targetProperty: 'maxNumOfTypeInCards'
});
const getNewStoryMaxNumOfIsCorrectCardsAdapterAtom = getAtomAdapter({
    targetAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStoryTemporaryInfoAtom"],
    targetProperty: 'maxNumOfIsCorrectCards'
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/Hr/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Hr": ()=>Hr,
    "HrWrapper": ()=>HrWrapper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
function Hr(param) {
    let { className } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-gray-300 my-2', className)
    }, void 0, false, {
        fileName: "[project]/src/components/general/Hr/index.tsx",
        lineNumber: 5,
        columnNumber: 16
    }, this);
}
_c = Hr;
function HrWrapper(param) {
    let { children, className } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Hr, {
                className: className
            }, void 0, false, {
                fileName: "[project]/src/components/general/Hr/index.tsx",
                lineNumber: 17,
                columnNumber: 25
            }, this),
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Hr, {
                className: className
            }, void 0, false, {
                fileName: "[project]/src/components/general/Hr/index.tsx",
                lineNumber: 19,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true);
}
_c1 = HrWrapper;
var _c, _c1;
__turbopack_context__.k.register(_c, "Hr");
__turbopack_context__.k.register(_c1, "HrWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/general/InputSwitch/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>InputSwitch
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function InputSwitch(param) {
    let { currState, setCurrState, testId } = param;
    const onChange = ()=>{
        setCurrState(!currState);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        "data-ischecked": currState,
        className: "relative flex w-10 h-6 p-0.5 has-[:checked]:!bg-blue-400 bg-red-100 duration-100 rounded-xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "checkbox",
                name: "toggle-input",
                "data-testid": testId,
                className: "absolute top-0 left-0 w-full h-full opacity-0 bg-transparent peer",
                checked: currState,
                onChange: onChange
            }, void 0, false, {
                fileName: "[project]/src/components/general/InputSwitch/index.tsx",
                lineNumber: 20,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex size-5 rounded-full bg-white shadow-md peer-checked:!ml-auto duration-100 z-[2] "
            }, void 0, false, {
                fileName: "[project]/src/components/general/InputSwitch/index.tsx",
                lineNumber: 28,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/general/InputSwitch/index.tsx",
        lineNumber: 17,
        columnNumber: 17
    }, this);
}
_c = InputSwitch;
var _c;
__turbopack_context__.k.register(_c, "InputSwitch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ParamWithToggleUI": ()=>ParamWithToggleUI
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$InputSwitch$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/InputSwitch/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Hr$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Hr/index.tsx [app-client] (ecmascript)");
;
;
;
function ParamWithToggleUI(param) {
    let { currState, setCurrState, title, testId } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Hr$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HrWrapper"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "flex justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "heading-3",
                    children: [
                        title,
                        ":"
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx",
                    lineNumber: 18,
                    columnNumber: 33
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$InputSwitch$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    currState,
                    setCurrState,
                    testId
                }, void 0, false, {
                    fileName: "[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx",
                    lineNumber: 19,
                    columnNumber: 33
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx",
            lineNumber: 17,
            columnNumber: 25
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx",
        lineNumber: 16,
        columnNumber: 17
    }, this);
}
_c = ParamWithToggleUI;
var _c;
__turbopack_context__.k.register(_c, "ParamWithToggleUI");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/NewStoryParamsDialog/client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CustomParam": ()=>CustomParam,
    "IsSmartModeToggle": ()=>IsSmartModeToggle,
    "ShowAnswersImmediatelyToggle": ()=>ShowAnswersImmediatelyToggle,
    "SubmitButton": ()=>SubmitButton
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/atomAdapters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Hr$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Hr/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/newStoryParamsModal.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/jotai@2.15.0_@babel+core@7.28.4_@babel+template@7.27.2_@types+react@19.2.2_react@19.2.0/node_modules/jotai/esm/react/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/getDefPathToPlayPage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$UI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/NewStoryParamsDialog/UI.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/jotai/historyAtoms.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function IsSmartModeToggle() {
    _s();
    const [currState, setCurrState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryIsSmartModeParamAdapterAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$UI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ParamWithToggleUI"], {
        currState,
        setCurrState,
        title: 'Smart mode',
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.isSmartModeInp
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
        lineNumber: 26,
        columnNumber: 17
    }, this);
}
_s(IsSmartModeToggle, "KOfV7vI7t5Oqnign3Y58rihMz6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"]
    ];
});
_c = IsSmartModeToggle;
function ShowAnswersImmediatelyToggle() {
    _s1();
    const [currState, setCurrState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryShowAnswersImmediatelyParamAdapterAtom"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$UI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ParamWithToggleUI"], {
        currState,
        setCurrState,
        title: 'Show answers immediately',
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.areAnswersShownImmediatelyInp
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
        lineNumber: 43,
        columnNumber: 17
    }, this);
}
_s1(ShowAnswersImmediatelyToggle, "KOfV7vI7t5Oqnign3Y58rihMz6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"]
    ];
});
_c1 = ShowAnswersImmediatelyToggle;
function CustomParam(param) {
    let { adapterAtom, title, maxNumAtom, testId } = param;
    _s2();
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"])(adapterAtom);
    const maxNum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(maxNumAtom);
    const isSmartMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryIsSmartModeParamAdapterAtom"]);
    const onChange = (e)=>{
        const newVal = e.target.value;
        const num = Number(newVal);
        if (num > maxNum || num < 0 || isSmartMode) return;
        setValue(num);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "heading-4",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                                lineNumber: 79,
                                columnNumber: 41
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "span",
                                children: "max. num. of cards: ".concat(maxNum)
                            }, void 0, false, {
                                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                                lineNumber: 80,
                                columnNumber: 41
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                        lineNumber: 78,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        "data-testid": testId,
                        "data-editable": !isSmartMode,
                        type: "number",
                        name: "newStoryParam",
                        value: String(value),
                        onInput: onChange,
                        className: "bg-gray-300 w-20 p-4 rounded-xl data-[editable=false]:bg-gray-200 data-[editable=false]:text-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                        lineNumber: 82,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                lineNumber: 77,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Hr$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hr"], {}, void 0, false, {
                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
                lineNumber: 92,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true);
}
_s2(CustomParam, "0KurosOZ+gxkJNwFvVbsZwaFvUo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtom"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomValue"]
    ];
});
_c2 = CustomParam;
function SubmitButton() {
    _s3();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const submit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"])({
        "SubmitButton.useAtomCallback[submit]": (get, set)=>{
            const newStorySettings = get(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["newStorySettingsAtom"]);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$newStoryParamsModal$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closeNewStorySettingsDialogAtom"]);
            set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$jotai$2f$historyAtoms$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addNewStoryAtom"], {
                settings: newStorySettings,
                bookId: newStorySettings.bookId,
                successCallback: {
                    "SubmitButton.useAtomCallback[submit]": (newStoryId)=>{
                        router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$getDefPathToPlayPage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(newStoryId));
                    }
                }["SubmitButton.useAtomCallback[submit]"]
            });
        }
    }["SubmitButton.useAtomCallback[submit]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        "data-testid": __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.submitBtn,
        onClick: submit,
        className: "bg-blue-400 border border-blue-700 hover:bg-blue-300 rounded-xl py-2 px-5 heading-4 duration-100 block my-6 !text-white ml-auto",
        children: "Submit"
    }, void 0, false, {
        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/client.tsx",
        lineNumber: 114,
        columnNumber: 17
    }, this);
}
_s3(SubmitButton, "zzmrhF2hUuNwEkLc6lEcrpLFMok=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$jotai$40$2$2e$15$2e$0_$40$babel$2b$core$40$7$2e$28$2e$4_$40$babel$2b$template$40$7$2e$27$2e$2_$40$types$2b$react$40$19$2e$2$2e$2_react$40$19$2e$2$2e$0$2f$node_modules$2f$jotai$2f$esm$2f$react$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAtomCallback"]
    ];
});
_c3 = SubmitButton;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "IsSmartModeToggle");
__turbopack_context__.k.register(_c1, "ShowAnswersImmediatelyToggle");
__turbopack_context__.k.register(_c2, "CustomParam");
__turbopack_context__.k.register(_c3, "SubmitButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/newCardParams.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "NEW_STORY_PARAMS": ()=>NEW_STORY_PARAMS
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/jotai/atomAdapters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
;
const NEW_STORY_PARAMS = [
    {
        title: 'Number of explicit cards',
        adapterAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryNumOfExplicitCardsParamAdapterAtom"],
        maxNumAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryMaxNumOfExplicitCardsAdapterAtom"],
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.numOfExpCardsInp
    },
    {
        title: 'Number of normal cards',
        adapterAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryNumOfNormalCardsParamAdapterAtom"],
        maxNumAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryMaxNumOfNormalCardsAdapterAtom"],
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.numOfNormCardsInp
    },
    {
        title: 'Number of cards, where you need to type in term text',
        adapterAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryNumOfTypeInCardsParamAdapterAtom"],
        maxNumAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryMaxNumOfTypeInCardsAdapterAtom"],
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.numOfTypeInCards
    },
    {
        title: 'Number of cards, where you need to choose if term-definition pair is correct',
        adapterAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryNumOfIsCorrectCardsParamAdapterAtom"],
        maxNumAtom: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$jotai$2f$atomAdapters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNewStoryMaxNumOfIsCorrectCardsAdapterAtom"],
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.numOfIsCorrectCards
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/books_page/NewStoryParamsDialog/index.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>NewStoryParamsDialog
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Dialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Dialog/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/NewStoryParamsDialog/client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$newCardParams$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/newCardParams.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/constants/testIds.ts [app-client] (ecmascript)");
;
;
;
;
;
function NewStoryParamsDialog() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Dialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        testId: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$testIds$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BP_TEST_IDS"].newStoryDialog.me,
        dialogName: "newStoryParams",
        className: "bg-white w-xl p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "heading-2",
                children: "Set up your new story"
            }, void 0, false, {
                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                lineNumber: 17,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IsSmartModeToggle"], {}, void 0, false, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                        lineNumber: 20,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ShowAnswersImmediatelyToggle"], {}, void 0, false, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                        lineNumber: 21,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "heading-3 mb-5",
                                    children: "Custom settings:"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                                    lineNumber: 24,
                                    columnNumber: 49
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                                lineNumber: 23,
                                columnNumber: 41
                            }, this),
                            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$newCardParams$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NEW_STORY_PARAMS"].map((param)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CustomParam"], {
                                    ...param
                                }, param.title, false, {
                                    fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                                    lineNumber: 29,
                                    columnNumber: 49
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                        lineNumber: 22,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SubmitButton"], {}, void 0, false, {
                        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                        lineNumber: 36,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
                lineNumber: 19,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/books_page/NewStoryParamsDialog/index.tsx",
        lineNumber: 13,
        columnNumber: 17
    }, this);
}
_c = NewStoryParamsDialog;
var _c;
__turbopack_context__.k.register(_c, "NewStoryParamsDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/(books)/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>MainPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@babel+core@7.28.4_@playwright+test@1.56.0_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$Header$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/Header/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/RenderBooks/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$AddBookButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/AddBookButton/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$initializers$2f$InitMainDbAtoms$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/initializers/InitMainDbAtoms.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Snackbar$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/general/Snackbar/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$BookStoryDialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/BookStoryDialog/index.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/books_page/NewStoryParamsDialog/index.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function MainPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$initializers$2f$InitMainDbAtoms$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/(books)/page.tsx",
                lineNumber: 14,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$general$2f$Snackbar$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                snackbarName: "noCardsErrorSnackbar",
                message: "In this book no question cards yet. Create one and try again"
            }, void 0, false, {
                fileName: "[project]/app/(books)/page.tsx",
                lineNumber: 15,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$BookStoryDialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/(books)/page.tsx",
                lineNumber: 19,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$NewStoryParamsDialog$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/(books)/page.tsx",
                lineNumber: 20,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "mainContainer",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$Header$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/(books)/page.tsx",
                        lineNumber: 22,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$RenderBooks$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/(books)/page.tsx",
                        lineNumber: 23,
                        columnNumber: 33
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$babel$2b$core$40$7$2e$28$2e$4_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$books_page$2f$AddBookButton$2f$index$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/(books)/page.tsx",
                        lineNumber: 24,
                        columnNumber: 33
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(books)/page.tsx",
                lineNumber: 21,
                columnNumber: 25
            }, this)
        ]
    }, void 0, true);
}
_c = MainPage;
var _c;
__turbopack_context__.k.register(_c, "MainPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_090126b4._.js.map