(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4421aabd._.js",
  "static/chunks/_75a178c8._.js",
  "static/chunks/30910_react-icons_io_index_mjs_5b923b9a._.js",
  "static/chunks/30910_react-icons_io5_index_mjs_51a8087b._.js",
  "static/chunks/30910_react-icons_md_index_mjs_df4fda87._.js",
  "static/chunks/30910_react-icons_fa6_index_mjs_2b7d7044._.js",
  "static/chunks/node_modules__pnpm_3db2edf6._.js"
],
    source: "dynamic"
});
