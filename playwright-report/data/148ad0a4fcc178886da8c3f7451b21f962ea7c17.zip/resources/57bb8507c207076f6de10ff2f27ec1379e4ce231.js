(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_initializers_InitMainDbAtoms_tsx_9d422d41._.js"
],
    source: "dynamic"
});
