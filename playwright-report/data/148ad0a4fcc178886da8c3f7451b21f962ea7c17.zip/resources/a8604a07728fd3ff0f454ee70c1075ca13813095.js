(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/30910_react-icons_bs_index_mjs_514070b9._.js",
  "static/chunks/30910_react-icons_fa_index_mjs_096e2568._.js",
  "static/chunks/30910_react-icons_lib_186b29c0._.js",
  "static/chunks/node_modules__pnpm_90bdd3a9._.js",
  "static/chunks/src_components_layout_Sidebar_de460222._.js",
  "static/chunks/app_globals_73c37791.css"
],
    source: "dynamic"
});
