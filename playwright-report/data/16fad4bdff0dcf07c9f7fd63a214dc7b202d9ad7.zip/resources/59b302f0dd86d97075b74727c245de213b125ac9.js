(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/main/add-collection/client.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/app_7d5770b5._.js",
  "static/chunks/node_modules__pnpm_1978701b._.js",
  {
    "path": "static/chunks/app_lib_commonComponents_QuestionCard_styles_39b9a514.css",
    "included": [
      "[project]/app/lib/commonComponents/QuestionCard/styles.css [app-client] (css)"
    ]
  },
  "static/chunks/app_main_add-collection_client_tsx_bb979ac6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/main/add-collection/client.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);