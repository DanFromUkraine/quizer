(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_7d5770b5._.js",
  "static/chunks/node_modules__pnpm_1978701b._.js",
  "static/chunks/app_lib_commonComponents_QuestionCard_styles_39b9a514.css"
],
    source: "dynamic"
});
