(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_b47ed0f9._.js",
  "static/chunks/node_modules__pnpm_1978701b._.js"
],
    source: "dynamic"
});
