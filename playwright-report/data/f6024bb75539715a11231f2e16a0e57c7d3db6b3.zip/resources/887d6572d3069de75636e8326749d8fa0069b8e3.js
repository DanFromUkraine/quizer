(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_08e02d9b._.js",
  "static/chunks/e98f6_next_dist_compiled_2c6c789e._.js",
  "static/chunks/e98f6_next_dist_client_4f176d4a._.js",
  "static/chunks/e98f6_next_dist_406b8951._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
