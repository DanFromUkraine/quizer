(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_main_add-collection_client_tsx_b57dd4f9._.js",
  "static/chunks/_a8e3caa1._.js"
],
    source: "dynamic"
});
